# Original IBJC application source

This archive contains the original React/vinext application, public pages,
officer dashboard, API handlers, database schema and migrations, validation,
spam protection, calendar generation, asset handling, and dependency lockfile.
See README.md for the original officer and developer instructions.

This is a full server application, not the portable three-file version.
It requires compatible Cloudflare Workers/D1/R2 hosting and the platform's
ChatGPT authentication integration. Moving it to a different hosting provider
requires adapting authentication and deployment; copying it to a static host
does not create a working admin area or registration database.

No production database, private submissions, officers, invitations, activation
codes, runtime secrets, installed dependencies, or build artifacts are included.
.env.example lists variable names with blank values. Configure new values in
the intended hosting environment; never embed secrets in public JavaScript.

The .openai/hosting.json file identifies the existing Site. Do not treat it as
a generic new deployment configuration or overwrite the existing Site while
experimenting with this export. The original live website was not modified.

public-content-export.json contains only the ten published records captured
September 16, 2026. Actual officer edits live in the database; lib/seed.ts is
the original sample content and does not represent the current live content.
The snapshot JSON is a reference export, not an automatic database restore.
Re-enter approved content through the dashboard or implement a reviewed import
for a new deployment. Private data migration is deliberately not included.

Run the documented install/build process before the integration tests. The
original README describes the Sites-managed development workflow; a different
provider needs its own environment configuration, authentication integration,
and database/file-store bindings. The editable HTML/CSS/JS version is supplied
in the separate IBJC-website.zip download.
