# Interdisciplinary Biology Journal Club

IBJC's public website and officer dashboard. Founded at Illinois Institute of Technology in Chicago in 2026; open to students, faculty, researchers, scientists, and community members.

## For officers

Open `/admin`, sign in with ChatGPT, and activate your account with the private setup link supplied to the owner. Sign-in establishes identity; only an approved officer role grants dashboard access. Never publish activation or invitation links. The first owner activation can be used only once. Owners can issue single-use, seven-day invitations for editors or administrators and remove officer access.

The dashboard's **Officer guide** includes the full day-to-day handover. Most changes do not require code or redeployment:

**About IBJC:** choose the About IBJC tab to edit all page headings, story, mission, goals, participation guidance, and sidebar text. Save draft, Preview saved draft, then Publish changes. Drafts remain private and do not replace the current public About page. The original logo and layout are preserved.

1. **Events:** choose New event, enter date and times in America/Chicago, location, host, description, and attendance notes. Set the food label (clear it to hide it) and registration toggle. Save a draft, open its saved page preview, then publish. A blank external registration URL enables the built-in form. Calendar links and the homepage update from the saved record. Events move to Past after their end time.
2. **Papers:** add citation fields, an official source, and legal full-text links; write the summary and discussion guide. Add topic, discipline, year, meeting type, presenter, and level for the filters. Copy the displayed paper ID into related events. Never upload a copyrighted paper without permission.
3. **News:** add a date, author, summary, article, tags, optional image, and related event or paper IDs. Newest posts appear first.
4. **Team:** enter approved names, roles, biography, affiliation, interests, photo, and optional public contact details. Leave the pending-information label enabled until missing details are approved. Initial faculty and biography placeholders are intentional.
5. **Resources and slides:** upload permitted PDF, PPTX, DOCX, TXT, PNG, JPG, or WebP files (15 MB maximum). Copy the resulting URL into a record's relevant file, slides, image, or photo field. A file stays private until referenced by published content. Resources also support text guides with automatic TXT downloads and a printable page.
6. **Private submissions:** owners and administrators can search registrations, newsletter records, and collaboration messages, export CSV, unsubscribe people, and delete records after confirmation. Editors manage content and uploads only. Preserve newsletter opt-outs as a suppression list unless responding to a deletion request.

Use Draft for unpublished work, Publish for public content, and Archive to remove content from public pages without deleting its history or registrations. Concurrent edits are rejected with a reload prompt. Save draft changes before opening the full page preview.

## Working now

- All nine public navigation sections, event and paper detail pages, news, team, orientation, privacy, participation notice, and 404 page.
- Public registration, newsletter signup, collaboration/contact forms, explicit consent, validation, error and success states, spam challenge, honeypot, replay protection, and rate limits.
- Durable D1 data, R2 uploads, server-enforced roles, protected attendee data, private previews, CSV exports with formula protection, and an audit trail of officer changes.
- Search and paper filters; event type/search filters, past/upcoming views, and month calendar.
- Downloadable calendars with America/Chicago and daylight-saving definitions, Google Calendar links, share actions, and downloadable/printable guides.
- Responsive menu and layouts, keyboard controls, page metadata, social preview image, sitemap, and robots rules.

## Integrations and content to complete

No confirmation or newsletter email is currently sent. Form success messages state this explicitly. Signups and opt-outs are saved in D1, and administrators can export CSV. The private unsubscribe link is displayed after a new signup; users should retain it. Contact IBJC through the form if that link is lost.

An optional provider adapter uses runtime `NEWSLETTER_WEBHOOK_URL` and `NEWSLETTER_WEBHOOK_TOKEN`. Configure an HTTPS endpoint that verifies the bearer token and maps subscribe/unsubscribe actions to your selected provider. Subscribe payloads contain the internal ID, name, email, institution, interests, consent version/time, and private unsubscribe URL. Unsubscribe payloads contain action, email, and ID. A non-2xx or failed request leaves the durable record intact and marks its provider status failed. No automatic resend queue is included: reconcile failures through the CSV list and provider suppression list before sending. Configure provider verification and unsubscribe handling, test end-to-end delivery, and update public integration notices before enabling campaigns. This adapter alone does not send emails.

No analytics or tracking pixels are configured. No credentials for a newsletter provider or custom domain are included. Faculty details, member biographies/photos, presenters, presentation slides, and direct paper PDF fields remain clearly identified as pending where no approved content was supplied. Existing paper links point to official and legal sources.

## Maintenance and development

This is a Sites/vinext React application with reusable components, Zod validation, Cloudflare D1, and R2. `.openai/hosting.json` binds this checkout to the existing Site; preserve its project ID. The site URL is defined in `lib/site-config.ts`; update it and the metadata if a custom domain is adopted.

- Public views: `components/public-content.tsx`, shared shell and form controls beside it.
- Officer interface: `components/admin-dashboard.tsx` and protected routes under `app/admin`.
- APIs: `app/api`; authorization, database helpers, and anti-spam in `lib/server.ts`.
- Data structure: `db/schema.ts` with schema-only migrations in `drizzle`.
- Initial content: `lib/seed.ts`, inserted only into an empty database. Officer changes are database records; editing the seed will not overwrite them.
- Branding: `public/brand/ibjc-logo.svg` displays the exact uploaded logo through an SVG viewport over the source graphic. Preserve its aspect ratio. The workshop poster is the supplied artwork. `public/og.png` is the social preview.

Required runtime secrets are `FORM_SECRET` (cryptographically random) and `ADMIN_BOOTSTRAP_SHA256` (SHA-256 of the private, random 64-hex owner activation code). Only the hash goes in environment settings. Remove the bootstrap secret after owner activation if desired. Do not commit `.env`, local databases, secrets, or exports. `.env.example` documents the variable names.

Use the Sites skill's configure, install, supervised preview, build, package, save, and deployment workflow. The selected local execution profile is ignored checkout state. For a managed Linux preview, start `sites-preview start /workspace/sites/ibjc`; do not expose that preview address as the live site.

Schema changes require a generated, reviewed migration (`db:generate`) and a fresh build. Apply pending migrations in order to the local preview with Wrangler's `d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file <migration>`. Sites applies packaged production migrations separately. Do not rerun already-applied local migrations or recreate live tables in request handlers.

After building, run `node scripts/qa-runtime.mjs` for the isolated Worker integration suite. It uses disposable D1/R2 and synthetic identities, applies the real migrations, and checks navigation, forms, permissions, drafts, files, CSV exports, calendars, privacy, metadata, and 404 responses. No test identities or submissions are inserted into production. Also check registration and newsletter controls in the supervised browser at desktop and mobile widths. Production ChatGPT authentication is dispatch-owned; local identity simulation in the integration suite tests role logic, not a real OAuth login.

## Usability review refinements

The public header uses Register; newsletter calls to action explicitly say newsletter. Selected meeting links are resolved before rendering, and unavailable links never select a different event. Optional affiliation and interest fields are collapsed. Paper search shows Topic and Reading level first, with the other four filters under More filters. The calendar and list share upcoming/past and search filters; phones show an agenda for the selected month.

The exact uploaded emblem is rendered by the shared ClubLogo component. Meeting and original-paper actions precede long content on mobile. Layout refinements are in app/experience.css, imported after the base theme. Known Pritzker room names expand to the official building name and campus directory link in lib/venues.ts; other locations keep their saved text. Event dates, descriptions, registration settings, and submitted data continue to come from the existing database.
