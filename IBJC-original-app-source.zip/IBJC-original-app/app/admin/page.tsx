import {getChatGPTUser,chatGPTSignInPath} from '@/app/chatgpt-auth';
import {officer,allContent} from '@/lib/server';
import {OfficerAccess,AdminDashboard} from '@/components/admin-dashboard';
import {SiteHeader,SiteFooter} from '@/components/site-shell';
export const dynamic='force-dynamic';
export const metadata={title:'Officer workspace',robots:{index:false,follow:false}};
export default async function Admin(){const user=await getChatGPTUser();const who=user?await officer():null;return <><SiteHeader/><main id="main" tabIndex={-1}>{who?<><div className="wrap"><p className="private-workspace-note"><strong>Private officer workspace.</strong> Public visitors cannot access this dashboard or private submissions. <a className="text-link" href="/">View the public website</a></p></div><AdminDashboard initialEntries={await allContent(false)} role={who.role} email={who.email}/></>:<div className="wrap page-content"><OfficerAccess signedIn={!!user} email={user?.email} signInPath={chatGPTSignInPath('/admin')}/></div>}</main><SiteFooter/></>}
