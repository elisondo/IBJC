import {getChatGPTUser,chatGPTSignInPath} from '@/app/chatgpt-auth';
import {officer,allContent} from '@/lib/server';
import {notFound} from 'next/navigation';
import {PublicSite} from '@/components/public-content';
export const dynamic='force-dynamic';
export const metadata={title:'Private content preview',robots:{index:false,follow:false}};
export default async function Preview({params}:{params:Promise<{id:string}>}){const {id}=await params;const who=await officer();if(!who)return <main className="wrap page-content"><h1>Officer access required</h1><p style={{margin:'20px 0'}}>Sign in with an authorized officer account to preview unpublished content.</p><a className="btn" href={chatGPTSignInPath('/admin/preview/'+id)} target="_top">Sign in with ChatGPT</a></main>;const entries=await allContent(false);const item=entries.find(e=>e.id===id);if(!item)notFound();const prefix=({event:'events',paper:'papers',news:'news',resource:'resources',team:'team',page:'about'} as const)[item.kind];return <><div className="status-banner">Private officer preview · {item.status} · Changes are not public until published. <a href="/admin" style={{textDecoration:'underline'}}>Return to dashboard</a></div><PublicSite path={item.kind==='page'?'/about':item.kind==='team'?'/team':'/'+prefix+'/'+item.slug} entries={entries.filter(e=>e.status==='published'||e.id===id)}/></>}
