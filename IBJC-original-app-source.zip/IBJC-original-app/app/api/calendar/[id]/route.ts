import {getEntry,apiError,ApiError} from '@/lib/server';
import {calendarFile} from '@/lib/calendar';
export const dynamic='force-dynamic';
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;const entry=await getEntry(id.replace(/\.ics$/,''));if(!entry||entry.kind!=='event')throw new ApiError(404,'Event not found.');return new Response(calendarFile(entry),{headers:{'Content-Type':'text/calendar; charset=utf-8','Content-Disposition':`attachment; filename="${entry.slug}.ics"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}})}catch(e){return apiError(e)}}
