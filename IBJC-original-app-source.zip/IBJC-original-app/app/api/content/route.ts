import {allContent,apiError,secureResponse} from '@/lib/server';
export const dynamic='force-dynamic';
export async function GET(){try{return secureResponse({entries:await allContent()})}catch(e){return apiError(e)}}
