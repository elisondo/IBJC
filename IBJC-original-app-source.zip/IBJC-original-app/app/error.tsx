"use client";
import {Button} from '@/components/ui/button';
export default function ErrorPage({reset}:{reset:()=>void}){return <main id="main" className="wrap page-content"><div className="notice error" role="alert"><h1 style={{fontSize:'2rem'}}>We couldn’t load this page.</h1><p style={{margin:'20px 0'}}>The service may be temporarily unavailable. Please try again.</p><Button className="btn" onClick={reset}>Try again</Button><a className="text-link" style={{marginLeft:20}} href="/">Return home</a></div></main>}
