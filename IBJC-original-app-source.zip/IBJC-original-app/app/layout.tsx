import type { Metadata } from 'next';
import './globals.css';
import './experience.css';
import {SITE_URL} from '@/lib/site-config';
export const metadata:Metadata={title:{default:'IBJC — Interdisciplinary Biology Journal Club',template:'%s | IBJC'},description:'Read research. Question evidence. Build scientific community. A student-led biology journal club founded at Illinois Tech and open to curious minds across Chicago.',metadataBase:new URL(SITE_URL),icons:{icon:'/brand/ibjc-logo.svg',shortcut:'/brand/ibjc-logo.svg'},openGraph:{title:'IBJC — Research is a conversation',description:'Read research, question evidence, and connect across biological disciplines in Chicago.',type:'website',locale:'en_US',url:SITE_URL,images:[{url:'/og.png',width:1733,height:907,alt:'IBJC — Interdisciplinary Biology Journal Club'}]},twitter:{card:'summary_large_image',title:'IBJC — Interdisciplinary Biology Journal Club',description:'Read research. Question evidence. Build scientific community.',images:['/og.png']},other:{'theme-color':'#0b2b4c'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
