import {allContent} from '@/lib/server';
import {PublicSite} from '@/components/public-content';
export const dynamic='force-dynamic';
export default async function Home(){return <PublicSite path="/" entries={await allContent()}/>}
