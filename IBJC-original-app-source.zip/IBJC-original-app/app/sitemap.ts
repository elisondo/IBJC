import {allContent} from '@/lib/server';
import {SITE_URL} from '@/lib/site-config';
export const dynamic='force-dynamic';
export default async function sitemap(){const pages=['','about','events','papers','news','team','resources','get-involved','contact','privacy','terms','join'];const entries=await allContent();const routes:Record<string,string>={event:'events',paper:'papers',news:'news',resource:'resources'};return [...pages.map(p=>({url:SITE_URL+'/'+p})),...entries.filter(e=>routes[e.kind]).map(e=>({url:SITE_URL+'/'+routes[e.kind]+'/'+e.slug,lastModified:e.updatedAt}))]}
