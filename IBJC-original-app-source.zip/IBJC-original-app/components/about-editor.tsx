"use client";
import {useEffect,useRef,useState} from 'react';
import {Button} from '@/components/ui/button';
import {Skeleton} from '@/components/ui/skeleton';
import {FormField} from './site-controls';
import {ABOUT_DEFAULTS,ABOUT_GROUPS,ABOUT_DRAFT_ID,type AboutData} from '@/lib/about';

export function AboutEditor(){
  const [data,setData]=useState<AboutData>(ABOUT_DEFAULTS),[revision,setRevision]=useState(0);
  const [loading,setLoading]=useState(true),[pending,setPending]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState(''),[dirty,setDirty]=useState(false);
  const feedback=useRef<HTMLDivElement>(null);
  function accept(state:any){setData(state.data);setRevision(state.revision);setDirty(false)}
  async function load(){setLoading(true);setError('');try{const response=await fetch('/api/admin?view=about',{cache:'no-store'});const result:any=await response.json();if(!response.ok)throw new Error(result.error);accept(result)}catch(e){setError((e as Error).message)}finally{setLoading(false)}}
  useEffect(()=>{void load()},[]);
  useEffect(()=>{if(error||message){feedback.current?.focus();feedback.current?.scrollIntoView({block:'center',behavior:'auto'})}},[error,message]);
  useEffect(()=>{if(!dirty)return;const warn=(event:BeforeUnloadEvent)=>{event.preventDefault();event.returnValue=''};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn)},[dirty]);
  async function save(mode:'draft'|'publish'){
    setPending(true);setError('');setMessage('');
    try{const response=await fetch('/api/admin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save-about',mode,revision,data})});const result:any=await response.json();if(!response.ok)throw new Error(result.error);accept(result.state);setMessage(result.message)}catch(e){setError((e as Error).message)}finally{setPending(false)}
  }
  if(loading)return <div className="about-editor" aria-label="Loading About IBJC editor"><Skeleton className="h-64 w-full"/></div>;
  return <section className="about-editor">
    <div className="admin-toolbar"><h2>Edit About IBJC</h2><a className="text-link" href="/about" target="_blank" rel="noreferrer">View public page</a></div>
    <p className="muted" style={{marginBottom:24}}>Edit the headings, mission, story, goals, and sidebar text. Blank lines create paragraphs. Your draft stays private until you publish.</p>
    {(error||message)&&<div ref={feedback} tabIndex={-1} role={error?'alert':'status'} className={'notice '+(error?'error':'success')}>{error||message}{error&&<div style={{marginTop:12}}><Button className="btn outline small" onClick={()=>void load()}>Reload editor</Button></div>}</div>}
    <form onSubmit={event=>{event.preventDefault();void save('publish')}}>
      {ABOUT_GROUPS.map(group=><fieldset key={group.title} disabled={pending}><legend>{group.title}</legend>{group.fields.map(field=><FormField key={field.key} id={'about-'+field.key} label={field.label+(field.required?' *':'')} value={data[field.key]} onChange={text=>{setData(previous=>({...previous,[field.key]:text}));setDirty(true);setMessage('')}} textarea={field.multiline} required={field.required} maxLength={field.multiline?20000:300}/>)}</fieldset>)}
      <div className="editor-section"><div className="actions">
        <Button className="btn outline" type="button" disabled={pending} onClick={()=>void save('draft')}>{pending?'Saving…':'Save draft'}</Button>
        {revision>0&&<a className="btn outline" href={'/admin/preview/'+ABOUT_DRAFT_ID} target="_blank" rel="noreferrer">Preview saved draft</a>}
        <Button className="btn gold" type="submit" disabled={pending}>{pending?'Saving…':'Publish changes'}</Button>
      </div><p className="fineprint" style={{marginTop:10}}>{dirty?'You have unsaved changes. Save before previewing.':revision>0?'Your draft is saved. Preview it or publish when ready.':'Save a draft to preview the full page before publishing.'}</p></div>
    </form>
  </section>;
}
