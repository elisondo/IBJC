"use client";
import {useState,useEffect,useRef} from 'react';
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem} from '@/components/ui/select';
import {Collapsible,CollapsibleTrigger,CollapsibleContent} from '@/components/ui/collapsible';
import {Button} from '@/components/ui/button';
import {Checkbox} from '@/components/ui/checkbox';
import {Input} from '@/components/ui/input';
import {Textarea} from '@/components/ui/textarea';
import {Share2,Check,ArrowRight,RefreshCw,ChevronDown} from 'lucide-react';
import {SITE_URL,participantTypes,prettyDate,timeLabel,type Entry} from '@/lib/site-config';

export function Choice({id,value,onChange,options,placeholder='Choose an option',required=false}:{id:string;value:string;onChange:(v:string)=>void;options:(string|{value:string;label:string})[];placeholder?:string;required?:boolean}){
  return <Select value={value||undefined} onValueChange={onChange}><SelectTrigger id={id} aria-required={required||undefined} className="choice-trigger min-h-[46px] w-full bg-white text-base border-[#c8d2df]"><SelectValue placeholder={placeholder}/></SelectTrigger><SelectContent className="choice-options max-w-[calc(100vw-2rem)]">{options.map(o=>{const x=typeof o==='string'?{value:o,label:o}:o;return <SelectItem key={x.value} value={x.value}>{x.label}</SelectItem>})}</SelectContent></Select>;
}
export function FormField({id,label,value,onChange,type='text',required=false,textarea=false,maxLength=250}:{id:string;label:string;value:string;onChange:(v:string)=>void;type?:string;required?:boolean;textarea?:boolean;maxLength?:number}){
  return <div className="field"><label htmlFor={id}>{label}{required?' *':''}</label>{textarea?<Textarea id={id} value={value} onChange={e=>onChange(e.target.value)} required={required} maxLength={maxLength}/>:<Input id={id} type={type} value={value} onChange={e=>onChange(e.target.value)} required={required} maxLength={maxLength} autoComplete={type==='email'?'email':id.endsWith('name')?'name':undefined}/>}</div>;
}
export function ShareButton({path,title}:{path:string;title:string}){const [copied,setCopied]=useState(false);const [error,setError]=useState(false);async function share(){try{if(navigator.share){await navigator.share({title,url:SITE_URL+path})}else{await navigator.clipboard.writeText(SITE_URL+path);setCopied(true)}}catch(e){if((e as Error).name!=='AbortError')setError(true)}}return <><Button type="button" className="btn outline small" onClick={share}>{copied?<Check/>:<Share2/>}{copied?'Link copied':'Share'}</Button>{error&&<span className="fineprint">Copy the page address from your browser to share.</span>}</>}
const intents=['Present a paper','Suggest a paper','Lead a workshop','Give a research presentation','Collaborate','Sponsor or support','Communications, design & outreach','General question','Accessibility or campus access','Privacy or subscription request'];

export function PublicForm({mode,events=[],eventId='',compact=false,initialIntent=''}:{mode:'register'|'newsletter'|'inquiry';events?:Entry[];eventId?:string;compact?:boolean;initialIntent?:string}){
  const [v,setV]=useState<Record<string,string>>({name:'',email:'',affiliation:'',institution:'',interests:'',participantType:'',eventId,intent:initialIntent,website:'',answer:''});
  const [privacy,setPrivacy]=useState(false),[consent,setConsent]=useState(false),[pending,setPending]=useState(false),[result,setResult]=useState<any>(null),[error,setError]=useState(''),[captcha,setCaptcha]=useState<any>(null);
  const feedback=useRef<HTMLDivElement>(null);
  const set=(key:string,value:string)=>setV(o=>({...o,[key]:value}));
  const prefix=mode+(compact?'-compact':'');
  async function refresh(){setCaptcha(null);try{const r=await fetch('/api/forms',{cache:'no-store'});const d:any=await r.json();if(!r.ok)throw new Error(d.error);setCaptcha(d)}catch(e){setError((e as Error).message)}}
  useEffect(()=>{refresh()},[]);
  useEffect(()=>{if(error||result){feedback.current?.focus({preventScroll:true});feedback.current?.scrollIntoView({block:'center'});}},[error,result]);
  async function submit(e:React.FormEvent){
    e.preventDefault();
    if(mode==='register'&&!v.eventId){setError('Choose the meeting you want to attend.');return}
    if(mode==='register'&&!v.participantType){setError('Choose your participant type. Community members are welcome.');return}
    if(mode==='inquiry'&&!v.intent){setError('Choose how we can help.');return}
    if(mode==='newsletter'&&!consent){setError('Please agree to receive newsletter updates.');return}
    if(!privacy){setError('Please acknowledge the privacy notice.');return}
    if(!captcha){setError('Refresh the spam-prevention question to continue.');return}
    setPending(true);setError('');
    try{const r=await fetch('/api/forms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...v,action:mode,privacy,consent,newsletterConsent:consent,challengeToken:captcha.token})});const data:any=await r.json();if(!r.ok)throw new Error(data.error);setResult(data)}catch(e){setError((e as Error).message);set('answer','');await refresh()}finally{setPending(false)}
  }
  const event=events.find(e=>e.id===v.eventId);
  if(result)return <div className="notice success" ref={feedback} tabIndex={-1} role="status"><h2 className="form-success-title">{mode==='register'?'Registration saved.':mode==='newsletter'?'Your newsletter signup is saved.':'Your message is saved.'}</h2><p>{result.message}</p>{event&&<div className="success-event"><strong>{event.title}</strong><p>{prettyDate(event.data.date)} · {timeLabel(event.data.start)}–{timeLabel(event.data.end)} · Chicago time<br/>{event.data.location}</p><div className="actions"><a className="btn small" href={'/api/calendar/'+event.id+'.ics'}>Add to calendar</a><a className="btn outline small" href={'/events/'+event.slug}>Return to event</a></div></div>}{(result.manageUrl||result.newsletter?.manageUrl)&&<div className="subscription-link"><p>Keep this private link to unsubscribe:</p><a className="manage-link" href={result.manageUrl||result.newsletter.manageUrl}>Your unsubscribe link</a><p className="fineprint">Bookmark or copy it. Only you should use this link.</p></div>}</div>;
  return <form onSubmit={submit} className={compact?'newsletter-form':'form-box'} aria-label={mode==='register'?'Event registration':mode==='newsletter'?'Newsletter signup':'Contact IBJC'}>
    <fieldset disabled={pending} aria-busy={pending} style={{border:0,padding:0,margin:0}}>
      <p className="form-required">* Required. No account or IIT email needed.</p>
      {mode==='register'&&<div className="event-selection">{(events.length>1||!event)&&<div className="field"><label htmlFor={prefix+'-event'}>Which meeting? *</label><Choice id={prefix+'-event'} value={v.eventId} onChange={s=>set('eventId',s)} required placeholder="Choose a meeting" options={events.map(e=>({value:e.id,label:e.title+' · '+prettyDate(e.data.date)}))}/></div>}{event&&<div className="registration-summary"><h2>{event.title}</h2><p>{prettyDate(event.data.date)}<br/>{timeLabel(event.data.start)}–{timeLabel(event.data.end)} · Chicago time<br/>{event.data.location}</p><a className="text-link" href={'/events/'+event.slug}>Meeting details & campus access</a></div>}</div>}
      <div className={compact?'newsletter-fields':'form-grid'}>
        <FormField id={prefix+'-name'} label="Name" value={v.name} onChange={s=>set('name',s)} required maxLength={120}/>
        <FormField id={prefix+'-email'} label="Email" type="email" value={v.email} onChange={s=>set('email',s)} required maxLength={254}/>
        {mode==='register'&&<div className="field full"><label htmlFor={prefix+'-type'}>Participant type *</label><Choice id={prefix+'-type'} value={v.participantType} onChange={s=>set('participantType',s)} options={participantTypes} required/></div>}
        {mode==='inquiry'&&<><div className="field full"><label htmlFor={prefix+'-intent'}>How would you like to connect? *</label><Choice id={prefix+'-intent'} value={v.intent} onChange={s=>set('intent',s)} options={intents} required/></div><div className="full"><FormField id={prefix+'-message'} label={v.intent==='Suggest a paper'?'Paper link and why you suggest it':'Your idea or question'} value={v.message||''} onChange={s=>set('message',s)} textarea maxLength={5000} required/></div></>}
      </div>
      {!compact&&<Collapsible className="optional-fields"><CollapsibleTrigger className="disclosure-button" type="button">{mode==='inquiry'?'Add an affiliation (optional)':'Add affiliation or interests (optional)'}<ChevronDown size={17}/></CollapsibleTrigger><CollapsibleContent><div className="form-grid"><FormField id={prefix+'-institution'} label="Affiliation or institution (optional)" value={mode==='newsletter'?v.institution:v.affiliation} onChange={s=>set(mode==='newsletter'?'institution':'affiliation',s)}/>{mode!=='inquiry'&&<FormField id={prefix+'-interests'} label="Research interests (optional)" value={v.interests} onChange={s=>set('interests',s)} maxLength={1000}/>}</div></CollapsibleContent></Collapsible>}
      <div className="hp" aria-hidden="true"><label htmlFor={prefix+'-website'}>Leave this blank</label><input tabIndex={-1} id={prefix+'-website'} value={v.website} onChange={e=>set('website',e.target.value)} autoComplete="off"/></div>
      {mode!=='inquiry'&&<div className="check"><Checkbox id={prefix+'-consent'} checked={consent} onCheckedChange={s=>setConsent(s===true)} aria-required={mode==='newsletter'||undefined}/><label htmlFor={prefix+'-consent'}>{mode==='newsletter'?'I agree to receive IBJC news and event updates. *':'Email me IBJC news and event updates too (optional).'} I can unsubscribe at any time.</label></div>}
      <div className="check"><Checkbox id={prefix+'-privacy'} checked={privacy} onCheckedChange={s=>setPrivacy(s===true)} aria-required="true"/><label htmlFor={prefix+'-privacy'}>I have read the <a href="/privacy" target="_blank" rel="noreferrer">privacy notice</a> and understand how IBJC uses my information. *</label></div>
      <div className="field spam-field"><label htmlFor={prefix+'-answer'}>{captcha?captcha.question+' *':'Loading spam-prevention question…'}</label><div className="spam-controls"><Input id={prefix+'-answer'} inputMode="numeric" value={v.answer} onChange={e=>set('answer',e.target.value)} required aria-describedby={prefix+'-spam-help'}/><Button variant="outline" type="button" onClick={refresh} aria-label="Refresh spam-prevention question"><RefreshCw size={16}/></Button></div><span id={prefix+'-spam-help'} className="fineprint">A quick check to reduce automated submissions.</span></div>
      {mode==='newsletter'&&<p className="delivery-note">Newsletter emails aren’t being sent yet. Your signup will be saved.</p>}
      {error&&<div className="notice error" ref={feedback} tabIndex={-1} role="alert">{error}</div>}
      <div className="submit-actions"><Button className={'btn '+(compact?'gold':'')} type="submit" disabled={pending||!captcha}>{pending?'Saving…':mode==='register'?'Complete registration':mode==='newsletter'?'Sign up for the newsletter':'Send to IBJC'}<ArrowRight/></Button></div>
      <p className="fineprint form-privacy">Only authorized IBJC administrators can view your submission. {mode!=='newsletter'&&'You’ll see confirmation on this page.'}</p>
    </fieldset>
  </form>;
}
export function Unsubscribe(){const [token,setToken]=useState(''),[pending,setPending]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState('');useEffect(()=>{const p=new URLSearchParams(location.hash.slice(1));setToken(p.get('token')||'')},[]);async function submit(){setPending(true);try{const r=await fetch('/api/forms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'unsubscribe',token})});const d:any=await r.json();if(!r.ok)throw new Error(d.error);setMessage(d.message);history.replaceState(null,'',location.pathname)}catch(e){setError((e as Error).message)}finally{setPending(false)}}return <div className="panel form-box"><h2 style={{fontSize:'1.6rem'}}>Manage your subscription</h2>{message?<div className="notice success" role="status">{message}</div>:token?<><p style={{margin:'20px 0'}}>Stop receiving IBJC newsletter updates. Event registrations remain unchanged.</p><Button className="btn" onClick={submit} disabled={pending}>{pending?'Updating…':'Unsubscribe from newsletter'}</Button></>:<p style={{marginTop:20}}>Open the private subscription link provided when you signed up. If you no longer have it, <a className="text-link" href="/contact?intent=Privacy%20or%20subscription%20request">contact IBJC for help</a>.</p>}{error&&<div className="notice error" role="alert">{error}</div>}</div>}
