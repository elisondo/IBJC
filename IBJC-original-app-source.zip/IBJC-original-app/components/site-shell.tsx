"use client";
import {useState} from 'react';
import {usePathname} from 'next/navigation';
import {Menu,ArrowRight} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Sheet,SheetTrigger,SheetContent,SheetHeader,SheetTitle,SheetDescription} from '@/components/ui/sheet';
export const navigation=[['Home','/'],['About IBJC','/about'],['Events','/events'],['Papers','/papers'],['News','/news'],['Team','/team'],['Orientation & Resources','/resources'],['Get Involved','/get-involved'],['Contact','/contact']];
export function ClubLogo({size=60}:{size?:number}){return <img className="ibjc-logo" src="/brand/ibjc-logo.svg" alt="IBJC logo" width={size} height={size}/>}
export function Brand(){return <a className="brand" href="/" aria-label="IBJC home"><ClubLogo/><span><strong>IBJC</strong><small>READ. QUESTION. CONNECT.</small></span></a>}
export function SiteHeader(){
  const pathname=usePathname();
  const [open,setOpen]=useState(false);
  const active=(url:string)=>pathname===url||(url!=='/'&&pathname.startsWith(url+'/'));
  return <><a className="skip-link" href="#main">Skip to content</a>
    <div className="topbar"><div className="wrap"><span>Student-led biology. Open to everyone.</span><span className="top-extra">Founded at Illinois Tech · Chicago</span></div></div>
    <header className="header"><div className="wrap header-row"><Brand/>
      <nav className="desktop-nav" aria-label="Main navigation">{navigation.map(([label,url])=><a className={active(url)?'active':''} aria-current={active(url)?'page':undefined} href={url} key={url}>{label}</a>)}</nav>
      <Button asChild className="btn gold nav-cta"><a href="/register">Register<span className="registration-cta-extra"> for an event</span></a></Button>
      <Sheet open={open} onOpenChange={setOpen}><SheetTrigger asChild><Button className="mobile-trigger" variant="outline" size="icon" aria-label="Open navigation"><Menu/></Button></SheetTrigger>
        <SheetContent className="mobile-menu"><SheetHeader><SheetTitle>Explore IBJC</SheetTitle><SheetDescription>No account or IIT affiliation needed to attend.</SheetDescription></SheetHeader>
          <nav className="mobile-nav-links" aria-label="Mobile navigation">{navigation.map(([label,url])=><a onClick={()=>setOpen(false)} className={active(url)?'active':''} aria-current={active(url)?'page':undefined} href={url} key={url}>{label}</a>)}<a onClick={()=>setOpen(false)} href="/join">Newsletter signup</a><a onClick={()=>setOpen(false)} className="btn gold" href="/register">Register for an event</a></nav>
        </SheetContent>
      </Sheet>
    </div></header>
  </>;
}
export function SiteFooter(){return <footer className="footer"><div className="wrap"><div className="footer-top"><div><Brand/><p>Interdisciplinary Biology Journal Club.<br/>A student-led scientific community founded at Illinois Institute of Technology, Chicago, in 2026.</p></div><div><h4>Explore</h4>{navigation.slice(1,6).map(([l,u])=><a className="footer-link" href={u} key={u}>{l}</a>)}</div><div><h4>Join the conversation</h4>{[['Attend an event','/events'],['Orientation & resources','/resources'],['Get involved','/get-involved'],['Join the newsletter','/join'],['Contact IBJC','/contact']].map(([l,u])=><a className="footer-link" key={u} href={u}>{l}</a>)}</div><div><h4>Chicago, together.</h4><p>For students, faculty, researchers, and curious minds across disciplines.</p><a className="text-link" style={{marginTop:17}} href="/get-involved">Collaborate with us <ArrowRight/></a></div></div><div className="footer-bottom"><span>© 2026 Interdisciplinary Biology Journal Club</span><div><a href="/privacy">Privacy</a><a href="/terms">Participation notice</a><a href="/admin">Officer sign in</a></div></div></div></footer>}
