import {z} from 'zod';
import {ABOUT_DEFAULTS,ABOUT_GROUPS,ABOUT_ID,ABOUT_DRAFT_ID,type AboutData} from './about';
import {db,ApiError,now,auditAction} from './server';
import {validate} from './validation';

const aboutSchema=z.object(Object.fromEntries(ABOUT_GROUPS.flatMap(group=>group.fields).map(field=>[
  field.key,z.string().trim().min(field.required?3:0,`${field.label} needs at least three characters.`).max(field.multiline?20000:300),
])));

export async function aboutEditorState(){
  const rows=await db().prepare('SELECT id,data,revision,updated_at FROM content WHERE id IN (?,?)').bind(ABOUT_ID,ABOUT_DRAFT_ID).all<{id:string;data:string;revision:number;updated_at:string}>();
  const draft=rows.results.find(row=>row.id===ABOUT_DRAFT_ID);
  const published=rows.results.find(row=>row.id===ABOUT_ID);
  const source=draft||published;
  return {
    data:aboutSchema.parse({...ABOUT_DEFAULTS,...(source?JSON.parse(source.data):{})}) as AboutData,
    revision:draft?.revision||0,
    savedAt:draft?.updated_at||null,
    publishedAt:published?.updated_at||null,
  };
}

export async function saveAbout(body:unknown,userId:string){
  const value=validate(z.object({mode:z.enum(['draft','publish']),revision:z.number().int().nonnegative(),data:aboutSchema}),body);
  const timestamp=now(),writeToken=crypto.randomUUID();
  const data=JSON.stringify(value.data),draftData=JSON.stringify({...value.data,_writeToken:writeToken});
  // Draft and live copy are separate records so a saved draft never hides the live page.
  const draft=value.revision===0
    ?db().prepare("INSERT INTO content (id,kind,slug,title,status,data,revision,updated_at) VALUES (?,'page','about-draft',?,'draft',?,1,?) ON CONFLICT(id) DO NOTHING").bind(ABOUT_DRAFT_ID,value.data.title,draftData,timestamp)
    :db().prepare("UPDATE content SET title=?,data=?,revision=revision+1,updated_at=? WHERE id=? AND kind='page' AND status='draft' AND revision=?").bind(value.data.title,draftData,timestamp,ABOUT_DRAFT_ID,value.revision);
  const statements=[draft];
  if(value.mode==='publish')statements.push(db().prepare("INSERT INTO content (id,kind,slug,title,status,data,revision,updated_at) SELECT ?,'page','about',?,'published',?,1,? FROM content WHERE id=? AND json_extract(data,'$._writeToken')=? ON CONFLICT(id) DO UPDATE SET title=excluded.title,data=excluded.data,revision=content.revision+1,updated_at=excluded.updated_at")
    .bind(ABOUT_ID,value.data.title,data,timestamp,ABOUT_DRAFT_ID,writeToken));
  // The unique token prevents a stale editor from publishing another officer's draft.
  const result=await db().batch(statements);
  if(!result[0].meta.changes)throw new ApiError(409,'Another officer updated About IBJC. Copy any unsaved text, then reload the editor before saving.');
  await auditAction(userId,value.mode==='publish'?'publish-about':'save-about-draft',ABOUT_ID);
  return {message:value.mode==='publish'?'About IBJC is published. Your changes are now live.':'Draft saved. The public About page is unchanged.',state:await aboutEditorState()};
}
