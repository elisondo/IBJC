// Existing About copy is the fallback until an officer publishes an update.
export const ABOUT_ID = 'page-about';
export const ABOUT_DRAFT_ID = 'page-about-draft';
export const ABOUT_DEFAULTS = {
  title: 'Research is a conversation.',
  description: 'We’re creating a place to understand biological research, ask thoughtful questions, and learn from one another.',
  storyLabel: 'Why IBJC exists',
  storyHeading: 'A bridge between the classroom and the research paper.',
  storyBody: 'Scientific papers can feel like a language of their own. IBJC offers a welcoming place to learn that language by using it: reading a study, talking through its figures, and asking what the evidence supports.\n\nFounded at Illinois Institute of Technology in Chicago in 2026, the Interdisciplinary Biology Journal Club is a student-led organization. Our public community welcomes students, faculty, researchers, scientists, and anyone in Chicago interested in biological research.',
  missionHeading: 'Our mission',
  mission: 'IBJC creates a space where students and researchers can engage with biological research across disciplines, learn how scientific arguments are built, question evidence carefully, and develop the confidence to participate in research conversations.',
  interdisciplinaryHeading: 'Why interdisciplinary biology?',
  interdisciplinaryBody: 'Biological questions rarely fit inside a single discipline. Understanding the brain can involve molecules, behavior, computation, and statistics. Studying ecosystems can connect genetics, environmental science, and data analysis. Different perspectives help us recognize both the strengths and the limits of an explanation.\n\nOur conversations welcome interests in biology, neuroscience, bioinformatics, molecular biology, computational biology, ecology, biotechnology, and related fields.',
  goalsHeading: 'What we practice',
  goals: 'Finding the question and tracing the argument behind a study.\nEvaluating methods, controls, figures, and uncertainty.\nCommunicating complicated ideas clearly.\nAsking useful questions and disagreeing respectfully.\nConnecting students with people working on research.',
  welcomeHeading: 'Learning at your own level',
  welcomeBody: 'You can listen, ask a basic question, share a perspective from your field, or help present a paper. You are not expected to understand every detail before you arrive. Our reading guides and guided discussions give you a starting point.',
  sidebarHeading: 'Student-led. Chicago-connected.',
  sidebarBody: 'Founded at Illinois Tech.\nBuilt around curiosity.\nOpen across disciplines.',
  teamLinkLabel: 'Meet the team',
  orientationHeading: 'Never read a paper?',
  orientationBody: 'You can still attend. Start with the abstract, bring one question, and let the conversation help fill in the gaps.',
  orientationLinkLabel: 'Start with orientation',
};
export type AboutData = typeof ABOUT_DEFAULTS;
export const ABOUT_GROUPS: {title:string;fields:{key:keyof AboutData;label:string;multiline?:boolean;required?:boolean}[]}[] = [
  {title:'Page introduction',fields:[{key:'title',label:'Page headline',required:true},{key:'description',label:'Short introduction',multiline:true,required:true}]},
  {title:'Why IBJC exists',fields:[{key:'storyLabel',label:'Section label'},{key:'storyHeading',label:'Heading'},{key:'storyBody',label:'Our story',multiline:true}]},
  {title:'Mission',fields:[{key:'missionHeading',label:'Heading'},{key:'mission',label:'Mission statement',multiline:true,required:true}]},
  {title:'Interdisciplinary biology',fields:[{key:'interdisciplinaryHeading',label:'Heading'},{key:'interdisciplinaryBody',label:'Description',multiline:true}]},
  {title:'Goals & participation',fields:[{key:'goalsHeading',label:'Goals heading'},{key:'goals',label:'Goals (one per line)',multiline:true},{key:'welcomeHeading',label:'Participation heading'},{key:'welcomeBody',label:'Participation description',multiline:true}]},
  {title:'Sidebar cards',fields:[{key:'sidebarHeading',label:'Club card heading'},{key:'sidebarBody',label:'Club card description',multiline:true},{key:'teamLinkLabel',label:'Team button label',required:true},{key:'orientationHeading',label:'Orientation card heading'},{key:'orientationBody',label:'Orientation card description',multiline:true},{key:'orientationLinkLabel',label:'Orientation button label',required:true}]},
];
