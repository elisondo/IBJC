export const SITE_URL='https://ibjc-chicago.ezelisondo.chatgpt.site';
export const TIME_ZONE='America/Chicago';
export type ContentKind='event'|'paper'|'news'|'team'|'resource'|'page';
export type Entry={id:string;kind:ContentKind;slug:string;title:string;status:'draft'|'published'|'archived';data:Record<string,any>;revision:number;updatedAt:string};
export const kinds:ContentKind[]=['event','paper','news','team','resource'];
export const eventTypes=['Paper discussion','Reading & analysis workshop','Research presentation'];
export const participantTypes=['Student','Faculty','Researcher','Scientist','Community member'];
export const teamGroups=['Executive board','Faculty advisors','Student presenters','Collaborators','Guest speakers & affiliated researchers'];
export const splitList=(s:string='')=>s.split(/\n|,/).map(x=>x.trim()).filter(Boolean);
export const prettyDate=(s:string)=>s?new Date(s.slice(0,10)+'T12:00:00Z').toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric',timeZone:'UTC'}):'Date to be announced';
export const todayChicago=()=>new Intl.DateTimeFormat('en-CA',{timeZone:TIME_ZONE,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export const timeLabel=(s:string)=>{if(!s)return '';const [h,m]=s.split(':').map(Number);return `${h%12||12}:${String(m).padStart(2,'0')} ${h>=12?'PM':'AM'}`};
export function safeLink(s:string|undefined){if(!s)return null;if(s.startsWith('/')&&!s.startsWith('//')&&!s.includes('\\'))return s;try{const u=new URL(s);return u.protocol==='https:'?u.href:null}catch{return null}}
