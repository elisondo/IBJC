// Campus building information, verified against Illinois Tech's venue directory.
// https://www.iit.edu/event-services/meeting-spaces/academic-space/robert-pritzker-science-center
// Match only the known room names; officers can use any other event location.
export function venueDetails(location:string=''){
  if(!['pritzker 111','ps 111'].includes(location.trim().toLowerCase()))return null;
  return {
    label:'Pritzker Science Center, Room 111',
    address:'3105 South Dearborn Street, Chicago, IL 60616',
    url:'https://www.iit.edu/event-services/meeting-spaces/academic-space/robert-pritzker-science-center',
  };
}
