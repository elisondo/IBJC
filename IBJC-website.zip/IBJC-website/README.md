# IBJC public website export

Open **index.html** in a modern browser. Keep it beside **style.css**, **script.js**, and the **assets** folder. No installation or build step is required.

This is a portable HTML/CSS/JavaScript adaptation of IBJC's public website. It preserves the original logo, navy/blue/gold identity, public page structure, and published content captured September 16, 2026. It is a snapshot: future changes in the officer dashboard do not automatically update these files.

## Files

- `index.html`: document, metadata, header, pre-rendered home page, and footer.
- `style.css`: readable CSS, including the original design and responsive rules.
- `script.js`: editable public content, page rendering, navigation, filters, calendar, and downloads.
- `assets/`: original IBJC logo and supplied promotional images. Keep the logo's aspect ratio.
- `public-content.json`: a reference copy of the ten published database records at export time. The website reads `CONTENT` in script.js, not this JSON file.

The separately supplied **IBJC-single-file.html** embeds the CSS, JavaScript, logo, and bundled artwork into one HTML document. The profile photo still uses its existing public image URL; if that image is unavailable, the person's initials appear. No copyrighted research-paper PDFs are bundled.

## What works in this export

- All public navigation sections and individual published event, paper, and news pages.
- Responsive navigation, keyboard focus, paper search and six filters.
- Upcoming/past event search, event-type filters, calendar and mobile agenda.
- Google Calendar links and downloadable `.ics` files with America/Chicago and daylight-saving definitions.
- Orientation questions, share links to the original live pages, privacy and participation notices, and a page-not-found view.
- Resource text downloads and printable resource pages when you add published resources. The current live resources are drafts, so they were not included in the public snapshot.

The CRISPR meeting on September 15, 2026 is correctly listed under Past meetings. There are no other published upcoming events in this snapshot. The workshop is currently unpublished; its separately published news announcement remains included.

## Forms and the private dashboard

Registration, newsletter signup, contact, collaboration, and officer sign-in links open the original live IBJC website in a new tab. The export clearly identifies this handoff. It does not collect personal data or simulate a successful submission.

The live server handles validation, spam protection, consent, database storage, unsubscribe links, roles, and private records. No registrations, subscriber lists, messages, officer identities, passwords, activation links, invitations, or runtime secrets are included.

Newsletter delivery was not connected at export time. The original site stores signups but does not send email until its provider integration is configured.

A protected editable dashboard cannot be implemented securely using only these three static files. The separate **IBJC-original-app-source.zip** contains the original React/server code for those features. It still requires server hosting, a database, file storage, authentication, and runtime secrets.

## Editing content

Open script.js in a text editor. The `CONTENT` array near the top holds events, papers, news, team members, and resources. Each record has:

```javascript
{
  id: 'a-unique-id',
  kind: 'event', // event, paper, news, team, resource, or page
  slug: 'a-readable-page-name',
  title: 'Your title',
  status: 'published',
  data: { /* fields for this record */ },
  revision: 1,
  updatedAt: '2026-09-16T12:00:00.000Z'
}
```

1. **Events:** copy an existing event and change its id, slug, title, date (`YYYY-MM-DD`), start/end (`HH:MM`, 24-hour Chicago time), location, type, description, host, food label, and registration setting. Clear `food` to hide its label. Increment revision when updating calendar information. If an event exists only in the static export, set `registrationUrl` to a real HTTPS registration page; the live site cannot accept an unknown event ID.
2. **Papers:** copy the existing paper and update the citation, legal source links, summary, methods, findings, limitations, discussion questions, tags, presenters, level, and related material links. Use an empty string for unavailable links.
3. **News:** use `date`, `author`, `summary`, `body`, `tags`, optional `image`, and optional related `eventId` / `paperId`. Separate body paragraphs with `\n\n`.
4. **Team:** use an existing team record's fields. Set `placeholder: true` until the biography and details are approved. Use exactly one of the names in `TEAM_GROUPS` for `group`. Do not invent credentials.
5. **About IBJC:** edit `ABOUT` below the content array. A published `page-about` record, if you later add one, overrides those defaults.
6. **Orientation:** edit `ORIENTATION`. To add a downloadable text guide, create a `resource` record whose data includes `description`, `body`, and optional HTTPS `fileUrl`.

Save and refresh your browser to see changes. Keep private drafts in your own working documents: even records marked `draft` inside a public JavaScript file can be read by visitors. The status flag hides rendering; it is not access control.

The home-page HTML in index.html is a pre-rendered fallback. JavaScript refreshes it from CONTENT when the page opens. If you change its content and need the fallback to match, update the home markup in index.html too. Edit the separated files first; the single-file copy does not automatically synchronize with them.

## Hosting and changing the address

Upload index.html, style.css, script.js, and assets together to a static web host. Hash routes such as `#/papers` work without rewrite rules and in a subfolder. Hosting alone does not transfer the original database or authentication.

Change `CONFIG.liveSite` only after the full backend has moved successfully. It controls secure forms, officer links, event URLs in calendar files, and share destinations. Until then, those actions continue to open the existing live website.

For social previews after hosting, replace the relative `og:image` value in index.html with your public absolute image URL and add your actual `og:url`. Hash routes are convenient for portability but do not provide separately crawlable HTML for each page; use the original server app when full search-engine indexing is required. Neither downloading nor hosting these files guarantees Google indexing.

## Verification

The export's JavaScript syntax, rendering of 18 public routes, internal route destinations, bundled asset paths, unique element IDs, and calendar timezone/content/line folding were checked. A live browser preview could not connect in this export environment; visually check desktop and phone layouts after opening or hosting the files. No live registration or newsletter submission was created for testing.

## Content notes

Published officer edits are preserved as written. The workshop news title currently says October 6 while its body says October 1; confirm the intended date before promoting it. The founder's research interests contain existing transcription errors. These are editable in CONTENT and in the live officer dashboard.
