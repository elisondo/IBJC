/*
 * IBJC — portable public website
 * No framework, build tools, tracking, or external JavaScript required.
 * Edit CONTENT for events, papers, news, people, and resources.
 * Edit ABOUT for the About page, and ORIENTATION for the reading FAQ.
 * Dates use America/Chicago. Only published records are rendered.
 * Secure forms and officer tools stay on the live application.
 */
'use strict';

const CONFIG = {
  liveSite: 'https://ibjc-chicago.ezelisondo.chatgpt.site',
  timeZone: 'America/Chicago',
  snapshotDate: '2026-09-16',
  siteTitle: 'IBJC — Interdisciplinary Biology Journal Club',
  description: 'Read research. Question evidence. Build scientific community. A student-led biology journal club founded at Illinois Tech and open to curious minds across Chicago.'
};

const CONTENT = [
  {
    "data": {
      "attendance": "Open to IIT students, faculty, researchers, and science-interested community members. No prior paper-reading experience required. Contact IBJC before attending if you need an accommodation or help with campus access.",
      "date": "2026-09-15",
      "description": "How can a bacterial defense system become a programmable tool for cutting DNA? Join a guided conversation about Jinek et al. (2012), the experiments behind CRISPR-Cas9, and what the evidence actually shows. We will introduce key terms, walk through the study, and leave time for questions. You can attend even if you have never read a research paper before.",
      "end": "13:45",
      "food": "Free Pizza",
      "host": "Ezequiel Lisondo, Diana Dimitrova, Dylan Thomas",
      "image": "",
      "location": "Pritzker 111, Robert A. Pritzker Science Center, 3105 S Dearborn St, Chicago, IL 60616",
      "paperId": "jinek-2012",
      "registrationOpen": true,
      "registrationUrl": "",
      "slides": "",
      "start": "12:45",
      "summary": "Explore the paper that made DNA cutting programmable. Jinek et al., 2012.",
      "timezone": "America/Chicago",
      "type": "Paper discussion"
    },
    "id": "crispr-cas9-2026",
    "kind": "event",
    "revision": 2,
    "slug": "crispr-cas9-2026",
    "status": "published",
    "title": "CRISPR-Cas9 Paper Discussion",
    "updatedAt": "2026-09-15T21:14:50.554Z"
  },
  {
    "data": {
      "affiliation": "",
      "bio": "Biography to be added.",
      "email": "",
      "group": "Executive board",
      "interests": "",
      "link": "",
      "photo": "",
      "placeholder": true,
      "role": "Executive Board"
    },
    "id": "diana-dimitrova",
    "kind": "team",
    "revision": 1,
    "slug": "diana-dimitrova",
    "status": "published",
    "title": "Diana Dimitrova",
    "updatedAt": "2026-09-15T11:00:00Z"
  },
  {
    "data": {
      "affiliation": "",
      "bio": "Biography to be added.",
      "email": "",
      "group": "Executive board",
      "interests": "",
      "link": "",
      "photo": "",
      "placeholder": true,
      "role": "Executive Board"
    },
    "id": "dylan-thomas",
    "kind": "team",
    "revision": 1,
    "slug": "dylan-thomas",
    "status": "published",
    "title": "Dylan Thomas",
    "updatedAt": "2026-09-15T11:00:00Z"
  },
  {
    "data": {
      "affiliation": "Bioinfomatics, B.S.",
      "bio": "I come from Puerto Rico and am interested in neuroscience, computational biology, and mycology research. Outside of academics, I enjoy soccer, surfing, camping, traveling, reading, and learning languages. I also love meeting new people and exploring new ideas, both in and outside of science.\n",
      "email": "elisondo@hawk.illinoistech.edu",
      "group": "Executive board",
      "interests": "Neural circuit mechanisms of psychosis and neurological disorders; ComputaBonal neuroscience and quanBtaBve biology; exploraBon of organic compounds as potenBal therapeuBcs; behavioral neuroscience; mycology; marine biology; ecology",
      "link": "https://www.linkedin.com/in/lisondo-ditada/",
      "photo": "https://cdn.phototourl.com/free/2026-09-15-cef361b7-c17d-401b-a323-11bb0b837282.jpg",
      "placeholder": false,
      "role": "Founder and President"
    },
    "id": "ezequiel-lisondo",
    "kind": "team",
    "revision": 5,
    "slug": "ezequiel-lisondo",
    "status": "published",
    "title": "Ezequiel Lisondo di Tada",
    "updatedAt": "2026-09-15T21:27:39.385Z"
  },
  {
    "data": {
      "affiliation": "",
      "bio": "Name and biography will be added after confirmation.",
      "email": "",
      "group": "Faculty advisors",
      "interests": "",
      "link": "",
      "photo": "",
      "placeholder": true,
      "role": "Advisor "
    },
    "id": "faculty-advisor",
    "kind": "team",
    "revision": 2,
    "slug": "faculty-advisor",
    "status": "published",
    "title": "Dr. Matthew Smith",
    "updatedAt": "2026-09-15T21:30:10.182Z"
  },
  {
    "data": {
      "author": "IBJC",
      "body": "Our first paper discussion focuses on CRISPR-Cas9 and the experiments that established RNA-guided DNA cutting. We will work through the central research question, introduce the vocabulary, and discuss the evidence together.\n\nThe meeting is on September 15, 2026, from 12:45 to 1:45 PM in Pritzker 111. Students, faculty, researchers, and curious community members are welcome.\n\nYou do not need to master the paper before attending. If you have ten minutes, read the abstract and write down one question. Our orientation resources can help you get started.",
      "date": "2026-09-15",
      "eventId": "crispr-cas9-2026",
      "image": "",
      "paperId": "jinek-2012",
      "summary": "Join us September 15 to explore Jinek et al. (2012). Read what you can and bring your questions.",
      "tags": "Paper selection, Events, Club updates"
    },
    "id": "first-paper-discussion",
    "kind": "news",
    "revision": 1,
    "slug": "first-paper-discussion",
    "status": "published",
    "title": "Our first paper conversation starts with CRISPR-Cas9",
    "updatedAt": "2026-09-15T11:00:00Z"
  },
  {
    "data": {
      "authors": "Martin Jinek; Krzysztof Chylinski; Ines Fonfara; Michael Hauer; Jennifer A. Doudna; Emmanuelle Charpentier",
      "disciplines": "Molecular biology, Biotechnology, Biochemistry",
      "discussionDate": "2026-09-15",
      "doi": "10.1126/science.1225829",
      "findings": "Cas9 uses two RNA partners for sequence-directed cleavage. An engineered single RNA can combine their functions and direct cutting at selected DNA sequences.",
      "hypothesis": "RNA pairing can specify the target, while Cas9 performs the DNA cutting.",
      "journal": "Science",
      "level": "Beginner",
      "limitations": "The study establishes a biochemical mechanism in laboratory reactions. It does not by itself demonstrate editing in human cells, clinical safety, or reliable targeting throughout an entire genome.",
      "materials": "",
      "meetingType": "Paper discussion",
      "methods": "The authors combined purified Cas9, RNA, and DNA in laboratory reactions. They compared RNA designs and protein variants, then examined DNA cleavage products.",
      "notes": "",
      "officialUrl": "https://www.science.org/doi/10.1126/science.1225829",
      "pdfUrl": "",
      "presenters": "Ezequiel Lisondo, Diana Dimitrova, Dylan Thomas",
      "question": "Can purified Cas9 and its RNA partners be programmed to cut a specific DNA target?",
      "questions": "Which comparison best supports the need for both RNA partners?\nWhat separates evidence for DNA cutting from evidence for genome editing?\nWhat experiment would you do next?",
      "repositoryUrl": "https://pmc.ncbi.nlm.nih.gov/articles/PMC6286148/",
      "slides": "",
      "summary": "This study showed that Cas9 can be directed to cut a chosen DNA sequence by RNA. It helped establish a simpler way to program a DNA-cutting system, using an engineered guide that joins two RNA components.",
      "topics": "CRISPR-Cas9, RNA-guided DNA cleavage",
      "year": "2012"
    },
    "id": "jinek-2012",
    "kind": "paper",
    "revision": 1,
    "slug": "jinek-2012",
    "status": "published",
    "title": "A Programmable Dual-RNA–Guided DNA Endonuclease in Adaptive Bacterial Immunity",
    "updatedAt": "2026-09-15T11:00:00Z"
  },
  {
    "data": {
      "author": "IBJC",
      "body": "Research papers ask you to follow an argument, evaluate its evidence, and decide what the results support. Our October 1 workshop will offer a practical introduction to that process.\n\nWe will meet from 12:45 to 1:45 PM in Pritzker 111. The faculty facilitator will be announced when confirmed. Students at any stage are welcome.",
      "date": "2026-09-15",
      "eventId": "paper-reading-workshop-2026",
      "image": "assets/workshop-poster.png",
      "paperId": "",
      "summary": "A faculty-led workshop on reading, analyzing, and discussing scientific papers. Facilitator to be announced.",
      "tags": "Workshops, Events"
    },
    "id": "learn-to-read-research",
    "kind": "news",
    "revision": 2,
    "slug": "learn-to-read-research",
    "status": "published",
    "title": "Coming October 6: learn to read research with confidence",
    "updatedAt": "2026-09-15T21:16:57.528Z"
  },
  {
    "data": {
      "affiliation": "",
      "bio": "Biography to be added",
      "email": "",
      "group": "Executive board",
      "interests": "",
      "link": "",
      "photo": "",
      "placeholder": true,
      "role": "Secretary "
    },
    "id": "team-1ac27585-e3f4-43f1-b7a9-2e44f7c16916",
    "kind": "team",
    "revision": 3,
    "slug": "ameerah-jaradat",
    "status": "published",
    "title": "Ameerah Jaradat",
    "updatedAt": "2026-09-15T21:31:00.538Z"
  },
  {
    "data": {
      "affiliation": "",
      "bio": "Biography to be added",
      "email": "",
      "group": "Executive board",
      "interests": "",
      "link": "",
      "photo": "",
      "placeholder": true,
      "role": "Treasurer "
    },
    "id": "team-caaa9f61-3a19-483d-a598-840a0d07cacb",
    "kind": "team",
    "revision": 2,
    "slug": "brooklyn-lawrence",
    "status": "published",
    "title": "Brooklyn Lawrence",
    "updatedAt": "2026-09-15T21:30:38.213Z"
  }
];
const ABOUT = {
  title: 'Research is a conversation.',
  description: 'We’re creating a place to understand biological research, ask thoughtful questions, and learn from one another.',
  storyLabel: 'Why IBJC exists',
  storyHeading: 'A bridge between the classroom and the research paper.',
  storyBody: 'Scientific papers can feel like a language of their own. IBJC offers a welcoming place to learn that language by using it: reading a study, talking through its figures, and asking what the evidence supports.\n\nFounded at Illinois Institute of Technology in Chicago in 2026, the Interdisciplinary Biology Journal Club is a student-led organization. Our public community welcomes students, faculty, researchers, scientists, and anyone in Chicago interested in biological research.',
  missionHeading: 'Our mission',
  mission: 'IBJC creates a space where students and researchers can engage with biological research across disciplines, learn how scientific arguments are built, question evidence carefully, and develop the confidence to participate in research conversations.',
  interdisciplinaryHeading: 'Why interdisciplinary biology?',
  interdisciplinaryBody: 'Biological questions rarely fit inside a single discipline. Understanding the brain can involve molecules, behavior, computation, and statistics. Studying ecosystems can connect genetics, environmental science, and data analysis. Different perspectives help us recognize both the strengths and the limits of an explanation.\n\nOur conversations welcome interests in biology, neuroscience, bioinformatics, molecular biology, computational biology, ecology, biotechnology, and related fields.',
  goalsHeading: 'What we practice',
  goals: 'Finding the question and tracing the argument behind a study.\nEvaluating methods, controls, figures, and uncertainty.\nCommunicating complicated ideas clearly.\nAsking useful questions and disagreeing respectfully.\nConnecting students with people working on research.',
  welcomeHeading: 'Learning at your own level',
  welcomeBody: 'You can listen, ask a basic question, share a perspective from your field, or help present a paper. You are not expected to understand every detail before you arrive. Our reading guides and guided discussions give you a starting point.',
  sidebarHeading: 'Student-led. Chicago-connected.',
  sidebarBody: 'Founded at Illinois Tech.\nBuilt around curiosity.\nOpen across disciplines.',
  teamLinkLabel: 'Meet the team',
  orientationHeading: 'Never read a paper?',
  orientationBody: 'You can still attend. Start with the abstract, bring one question, and let the conversation help fill in the gaps.',
  orientationLinkLabel: 'Start with orientation',
};
const ORIENTATION = [
['What is a journal club?','A journal club is a group that meets to discuss a research paper. We ask what the study tried to find out, how it tested the idea, what it found, and how convincing the evidence is. You learn by listening, asking, and comparing interpretations.'],
['How do IBJC meetings work?','We begin with the background and the main question. Presenters introduce unfamiliar terms and guide the group through the evidence. Questions are welcome throughout. We finish with limitations, implications, and the next questions the work raises.'],
['How should I prepare?','If you have ten minutes, read the abstract and write down one question. If you have more time, read the introduction and study one figure with its legend. You do not need to understand everything before attending.'],
['How do I read an abstract?','Look for four things: the problem, the approach, the main result, and the interpretation. Mark words you do not know. Try to summarize the study in one sentence, then check that sentence against the figures and main text.'],
['How do I identify the research question?','Ask what the authors did not know before the study. The question often appears near the end of the introduction. Keep it specific: what relationship, mechanism, or comparison is being tested? Distinguish the question from the answer the authors expect.'],
['How do I understand a figure?','Read the legend. Identify the groups, axes, units, scale, colors, and controls. Describe what you observe before interpreting it. Check sample size and what error bars mean. Ask which claim the figure supports and which claims it cannot address.'],
['How do I evaluate methods?','Ask whether the design can answer the question. Identify what was measured, how comparisons were made, and whether controls are appropriate. Look for independent replicates, possible confounding variables, and details needed to repeat the experiment.'],
['What is the difference between results and conclusions?','Results describe measurements and analyses. Conclusions interpret what those results mean. A change in a measured signal is a result; the claim that a specific mechanism caused that change is an interpretation that may require more evidence.'],
['How do I ask a useful scientific question?','Name the part you are asking about and explain your uncertainty. Try: “What does this control rule out?”, “Could another explanation fit this result?”, or “Why was this method chosen?” Basic clarification questions often help the entire room.'],
['How can I present a paper?','Use Get Involved to propose a paper and tell us what interests you. You can present with peers. A useful presentation explains the question, the key evidence, and the limitations, while leaving room for discussion. Officers can help coordinate the format and materials.'],
['How can I suggest a future paper?','Send the title, DOI or legal source link, a short explanation of why it would spark discussion, and any background members would need. Suggestions from any biological discipline are welcome.']
];

const NAVIGATION = [
  ['Home', '/'], ['About IBJC', '/about'], ['Events', '/events'],
  ['Papers', '/papers'], ['News', '/news'], ['Team', '/team'],
  ['Orientation & Resources', '/resources'], ['Get Involved', '/get-involved'], ['Contact', '/contact']
];
const TEAM_GROUPS = ['Executive board', 'Faculty advisors', 'Student presenters', 'Collaborators', 'Guest speakers & affiliated researchers'];
const PAPER_FILTERS = [
  ['topics', 'Topic'], ['level', 'Reading level'], ['disciplines', 'Discipline'],
  ['year', 'Publication year'], ['meetingType', 'Meeting type'], ['presenters', 'Presenter']
];

// Escape every content value before placing it in HTML.
function escapeHTML(value = '') {
  return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
}
function safeURL(value = '') {
  const url = String(value).trim();
  if (/^https:\/\//i.test(url) || /^assets\/[a-z0-9_.\/-]+$/i.test(url)) return url;
  if (/^\/api\/files\/[a-z0-9_.-]+$/i.test(url)) return CONFIG.liveSite + url;
  return '';
}
function externalLink(url, label, className = 'text-link') {
  const safe = safeURL(url);
  return safe ? `<a class="${className}" href="${escapeHTML(safe)}" target="_blank" rel="noopener noreferrer">${escapeHTML(label)} ${icon('external')}</a>` : '';
}
function link(path, label, className = 'text-link', arrow = true) {
  return `<a class="${className}" href="#${escapeHTML(path)}">${escapeHTML(label)}${arrow ? ' ' + icon('arrow') : ''}</a>`;
}
function splitList(value) { return String(value || '').split(/[,\n]/).map(x => x.trim()).filter(Boolean); }
function entries(kind) { return CONTENT.filter(e => e.status === 'published' && e.kind === kind); }
function byId(id) { return CONTENT.find(e => e.status === 'published' && e.id === id); }
function paragraphs(value) {
  return String(value || '').split(/\n\s*\n/).filter(Boolean).map(p => `<p class="preline">${escapeHTML(p)}</p>`).join('');
}
function tags(value) { return `<div class="tag-row">${splitList(value).map(t => `<span class="pill">${escapeHTML(t)}</span>`).join('')}</div>`; }
function prettyDate(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) return 'Date to be announced';
  return new Date(date + 'T12:00:00Z').toLocaleDateString('en-US', {month:'long', day:'numeric', year:'numeric', timeZone:'UTC'});
}
function timeLabel(time) {
  if (!/^\d{2}:\d{2}$/.test(time || '')) return 'Time to be announced';
  const [h,m] = time.split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2,'0')} ${h >= 12 ? 'PM' : 'AM'}`;
}
function chicagoNow() {
  return new Intl.DateTimeFormat('sv-SE', {timeZone:CONFIG.timeZone, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hour12:false}).format(new Date());
}
function eventHasEnded(event) { return `${event.data.date} ${event.data.end}` < chicagoNow(); }
function upcomingEvents() { return entries('event').filter(e => !eventHasEnded(e)).sort(compareEvents); }
function compareEvents(a,b) { return (a.data.date + a.data.start).localeCompare(b.data.date + b.data.start); }

// Simple interface icons; the supplied IBJC logo is kept as its original asset.
function icon(name) {
  const shapes = {
    arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
    external:'<path d="M14 4h6v6M20 4l-9 9M10 4H4v16h16v-6"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v5m10-5v5M3 11h18"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    pin:'<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2"/>',
    book:'<path d="M12 5v16M3 4c4-1 6 0 9 1 3-1 5-2 9-1v15c-4-1-6 0-9 2-3-2-5-3-9-2Z"/>',
    discussion:'<path d="M4 4h16v12H9l-5 5Z"/><path d="M8 8h8M8 12h5"/>',
    presentation:'<path d="M3 3h18v13H3ZM12 16v5m-5 0 5-5 5 5M7 11l4-4 3 3 3-4"/>',
    people:'<circle cx="9" cy="7" r="3"/><path d="M3 21v-4a6 6 0 0 1 12 0v4m2-17a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 4v3"/>',
    search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
    menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
    share:'<path d="M12 15V3m-5 5 5-5 5 5M5 12v9h14v-9"/>',
    file:'<path d="M5 3h9l5 5v13H5ZM14 3v6h5M8 13h8M8 17h6"/>'
  };
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${shapes[name] || shapes.book}</svg>`;
}
function logo(size = 60) { return `<img class="ibjc-logo" src="assets/ibjc-logo.svg" width="${size}" height="${size}" alt="IBJC logo">`; }
function brand() { return `<a class="brand" href="#/" aria-label="IBJC home">${logo()}<span><strong>IBJC</strong><small>READ. QUESTION. CONNECT.</small></span></a>`; }
function siteHeader() {
  const links = NAVIGATION.map(([label,path]) => link(path,label,'nav-link',false)).join('');
  return `<a class="skip-link" href="#main">Skip to content</a>
    <div class="topbar"><div class="wrap"><span>Student-led biology. Open to everyone.</span><span class="top-extra">Founded at Illinois Tech · Chicago</span></div></div>
    <header class="header"><div class="wrap header-row">${brand()}
      <nav class="desktop-nav" aria-label="Main navigation">${links}</nav>
      ${link('/register','Register for an event','btn gold nav-cta',false)}
      <button type="button" class="mobile-trigger btn outline" aria-label="Open navigation" aria-expanded="false" aria-controls="mobile-navigation">${icon('menu')}</button>
    </div><nav id="mobile-navigation" class="mobile-nav-links" aria-label="Mobile navigation" hidden>${links}${link('/join','Newsletter signup','nav-link',false)}${link('/register','Register for an event','btn gold',false)}</nav></header>`;
}
function siteFooter() {
  return `<footer class="footer"><div class="wrap"><div class="footer-top">
    <div>${brand()}<p>Interdisciplinary Biology Journal Club.<br>A student-led scientific community founded at Illinois Institute of Technology, Chicago, in 2026.</p></div>
    <div><h4>Explore</h4>${NAVIGATION.slice(1,6).map(([label,path]) => link(path,label,'footer-link',false)).join('')}</div>
    <div><h4>Join the conversation</h4>${[['Attend an event','/events'],['Orientation & resources','/resources'],['Get involved','/get-involved'],['Join the newsletter','/join'],['Contact IBJC','/contact']].map(([label,path]) => link(path,label,'footer-link',false)).join('')}</div>
    <div><h4>Chicago, together.</h4><p>For students, faculty, researchers, and curious minds across disciplines.</p>${link('/get-involved','Collaborate with us')}</div>
    </div><div class="footer-bottom"><span>© ${new Date().getFullYear()} Interdisciplinary Biology Journal Club</span><div>${link('/privacy','Privacy','',false)}${link('/terms','Participation notice','',false)}<a href="${CONFIG.liveSite}/admin" target="_blank" rel="noopener noreferrer">Officer sign in ${icon('external')}</a></div></div></div></footer>`;
}
function pageIntro(title, label, description = '', back = '') {
  return `<section class="page-intro"><div class="wrap"><nav class="breadcrumb" aria-label="Breadcrumb">${link('/','Home','',false)}<span aria-hidden="true">/</span>${back ? link(back,label,'',false) : `<span aria-current="page">${escapeHTML(label || title)}</span>`}</nav><h1>${escapeHTML(title)}</h1>${description ? `<p class="lead">${escapeHTML(description)}</p>` : ''}</div></section>`;
}
function emptyState(title, body, actions = '') { return `<div class="empty-state"><h3>${escapeHTML(title)}</h3><p>${escapeHTML(body)}</p><div class="actions">${actions}</div></div>`; }
function shareButton(path,title) { return `<button type="button" class="btn outline small" data-share="${escapeHTML(path)}" data-title="${escapeHTML(title)}">${icon('share')} Share</button><span class="fineprint share-feedback" role="status"></span>`; }

// Secure workflows remain with the original server. No personal data is stored here.
function securePanel(mode, eventId = '', intent = '') {
  const options = {
    register: ['Complete your registration','No account or IIT email is needed. Enter your details on IBJC’s secure registration page.','Open event registration','/register' + (eventId ? '?event=' + encodeURIComponent(eventId) : '')],
    newsletter: ['Join the IBJC newsletter','Sign up with any email address. Consent and unsubscribe preferences are managed on the live IBJC website.','Open newsletter signup','/join'],
    inquiry: ['Send a note to IBJC','Share your question, paper suggestion, or collaboration idea with the officers through the secure contact form.','Open contact form','/contact' + (intent ? '?intent=' + encodeURIComponent(intent) : '')]
  };
  const [heading,body,label,path] = options[mode];
  return `<div class="panel secure-panel"><h3>${heading}</h3><p>${body}</p>${externalLink(CONFIG.liveSite + path,label,'btn ' + (mode === 'register' ? 'gold' : ''))}<p class="fineprint">Opens the live IBJC website in a new tab. This exported copy does not collect or save submissions.</p>${mode === 'newsletter' ? '<p class="fineprint">As of this export, newsletter delivery is not connected. The live site saves signups and explains the current delivery status.</p>' : ''}</div>`;
}
function newsletterBand() {
  return `<section class="newsletter-band" id="newsletter"><div class="wrap"><div><div class="eyebrow">IBJC newsletter</div><h2>Stay up to date.</h2><p>Sign up for future meeting announcements, paper selections, and club news.</p><p class="fineprint">Open to everyone. No IIT email or account needed.</p></div>${securePanel('newsletter')}</div></section>`;
}
function eventMeta(event) {
  const d = event.data;
  return `<div class="event-meta">${icon('calendar')}<time datetime="${escapeHTML(d.date)}">${prettyDate(d.date)}</time></div><div class="event-meta">${icon('clock')}${timeLabel(d.start)}–${timeLabel(d.end)} · Chicago time</div><div class="event-meta">${icon('pin')}${escapeHTML(d.location)}</div>`;
}
function registrationLink(event, label = 'Register', className = 'btn gold') {
  return safeURL(event.data.registrationUrl) ? externalLink(event.data.registrationUrl,label,className) : link('/register?event=' + encodeURIComponent(event.id),label,className);
}
function calendarDownloadLink(event,label = 'Add to calendar') {
  return `<button type="button" class="text-link download-link" data-calendar="${escapeHTML(event.id)}">${icon('calendar')} ${label}</button>`;
}
function featureEvent(event) {
  if (!event) return `<div class="panel"><div class="eyebrow">Upcoming meetings</div><h2>Our next meeting is being planned.</h2><p class="spaced">Sign up for future announcements, or explore a previous paper discussion.</p>${link('/join','Newsletter signup','btn')}</div>`;
  const d = event.data;
  return `<article class="feature-event"><div class="event-art">${logo(52)}<span>Next meeting</span></div><div class="event-body"><div class="event-kicker"><span class="pill">${escapeHTML(d.type)}</span>${d.food ? `<span class="pill gold">${escapeHTML(d.food)}</span>` : ''}</div><h2>${link('/events/' + event.slug,event.title,'',false)}</h2><p class="summary">${escapeHTML(d.summary)}</p>${eventMeta(event)}<div class="actions">${d.registrationOpen ? registrationLink(event) : '<span class="pill neutral">Registration not open</span>'}${link('/events/' + event.slug,'Event details','btn outline',false)}</div><div class="calendar-link">${calendarDownloadLink(event)}</div></div></article>`;
}
function eventRow(event) {
  const d = event.data;
  const month = new Date(d.date + 'T12:00:00Z').toLocaleDateString('en-US',{month:'short',timeZone:'UTC'});
  return `<article class="event-row"><div class="date-block" aria-hidden="true"><small>${month}</small><strong>${Number(d.date.slice(8))}</strong></div><div><span class="pill">${escapeHTML(d.type)}</span><h3>${link('/events/' + event.slug,event.title,'',false)}</h3><div class="row-meta"><time datetime="${escapeHTML(d.date)}">${prettyDate(d.date)}</time><span>${icon('clock')}${timeLabel(d.start)}–${timeLabel(d.end)} · Chicago time</span><span>${icon('pin')}${escapeHTML(d.location)}</span>${d.food ? `<span>${escapeHTML(d.food)}</span>` : ''}</div></div><div class="event-row-actions">${d.registrationOpen && !eventHasEnded(event) ? registrationLink(event,'Register','btn gold small') : ''}${link('/events/' + event.slug,'Event details')}</div></article>`;
}
function paperCard(paper) {
  const d = paper.data;
  const short = (d.summary || '').length > 240 ? d.summary.slice(0,240).replace(/\s+\S*$/,'') + '…' : d.summary;
  return `<article class="paper-preview"><div class="paper-cover" aria-hidden="true"><span>${escapeHTML(d.journal)} · ${escapeHTML(d.year)}</span><strong>${escapeHTML(splitList(d.topics)[0] || 'Research paper')}</strong><span>IBJC PAPER SERIES</span></div><div><div class="tag-row"><span class="pill">${escapeHTML(d.level)}</span><span class="pill neutral">${escapeHTML(d.meetingType)}</span></div><h3>${link('/papers/' + paper.slug,paper.title,'',false)}</h3><span class="fineprint">${escapeHTML((d.authors || '').split(';')[0])} et al. · ${escapeHTML(d.journal)} · ${escapeHTML(d.year)}</span><p>${escapeHTML(short)}</p>${link('/papers/' + paper.slug,'Read summary & discussion guide')}</div></article>`;
}
function renderHome() {
  const upcoming = upcomingEvents(), paper = entries('paper')[0];
  const formats = [['book','Paper discussions','Unpack a study’s question, figures, and evidence with a guided group discussion.','Explore the papers','/papers'],['discussion','Reading & analysis workshops','Practice reading figures, evaluating methods, and asking useful scientific questions.','Find a workshop','/events'],['presentation','Research presentations','Hear from faculty, researchers, and students, and connect their work with your interests.','See upcoming meetings','/events']];
  return `<section class="hero"><div class="wrap hero-grid"><div><div class="eyebrow">Student-led · Chicago</div><h1>Interdisciplinary<br>Biology Journal Club</h1><p class="hero-tagline">Read research. Question evidence.<br>Build scientific <span class="gold-line">community.</span></p><p class="hero-description">A student-led journal club founded at Illinois Tech, open to anyone in Chicago curious about biological research.</p><div class="actions hero-actions">${link('/events','Upcoming meetings','btn')}${link('/join','Newsletter signup','text-link',false)}</div><div class="hero-welcome">${icon('people')}New to research papers? You can still attend.</div></div>${featureEvent(upcoming[0])}</div></section>
    <div class="subject-strip"><div class="wrap">${['Biology across disciplines','Molecular biology','Neuroscience','Bioinformatics','Ecology','Biotechnology'].map(x => `<span>${x}</span>`).join('')}</div></div>
    ${upcoming.length > 1 ? `<section class="section tint"><div class="wrap"><div class="section-heading"><h2>More upcoming meetings</h2>${link('/events','All events')}</div><div class="event-list">${upcoming.slice(1,4).map(eventRow).join('')}</div></div></section>` : ''}
    <section class="section"><div class="wrap"><div class="section-heading"><div><div class="eyebrow">What we do</div><h2>Three ways to explore biology.</h2><p>Learn with students, faculty, researchers, and curious community members.</p></div>${link('/about','About IBJC')}</div><div class="cards-3">${formats.map(([symbol,title,body,label,path]) => `<article class="format-card"><div class="icon-box">${icon(symbol)}</div><h3>${title}</h3><p>${body}</p>${link(path,label)}</article>`).join('')}</div></div></section>
    <section class="section tint"><div class="wrap"><div class="section-heading"><div><div class="eyebrow">From the reading list</div><h2>Our latest paper discussion</h2></div>${link('/papers','All papers')}</div>${paper ? paperCard(paper) : emptyState('Our reading list is growing','Suggest a paper through Get Involved.')}</div></section>
    ${newsletterBand()}<section class="section"><div class="wrap collaborate"><div><div class="eyebrow">Faculty, researchers & students</div><h2>Share a paper or your research.</h2><p>Present a paper, lead a workshop, or propose a collaboration with IBJC.</p></div>${link('/get-involved','Present or collaborate','btn')}</div></section>`;
}
function renderAbout() {
  const d = {...ABOUT,...entries('page').find(e => e.id === 'page-about')?.data};
  const section = (heading,body) => `${heading ? `<h2>${escapeHTML(heading)}</h2>` : ''}${paragraphs(body)}`;
  return pageIntro(d.title,'About IBJC',d.description) + `<div class="wrap page-content two-column"><article class="prose"><div class="eyebrow">${escapeHTML(d.storyLabel)}</div><h2 class="first-heading">${escapeHTML(d.storyHeading)}</h2>${paragraphs(d.storyBody)}${section(d.missionHeading,d.mission)}${section(d.interdisciplinaryHeading,d.interdisciplinaryBody)}<h2>${escapeHTML(d.goalsHeading)}</h2><ul>${d.goals.split('\n').filter(Boolean).map(x => `<li>${escapeHTML(x)}</li>`).join('')}</ul>${section(d.welcomeHeading,d.welcomeBody)}</article><aside class="aside-stack"><div class="panel tinted"><div class="about-logo">${logo(150)}</div><h3>${escapeHTML(d.sidebarHeading)}</h3><p class="preline">${escapeHTML(d.sidebarBody)}</p>${link('/team',d.teamLinkLabel,'btn outline')}</div><div class="panel"><h3>${escapeHTML(d.orientationHeading)}</h3><p>${escapeHTML(d.orientationBody)}</p>${link('/resources',d.orientationLinkLabel,'btn')}</div></aside></div>`;
}

// Search and calendar controls update just their results, keeping keyboard focus.
let eventState = {period:'upcoming', query:'', type:'all', view:'list', month:''};
function selectControl(id,label,values,firstLabel) {
  return `<div class="field"><label for="${id}">${label}</label><select id="${id}"><option value="all">${firstLabel}</option>${values.map(v => `<option value="${escapeHTML(v)}">${escapeHTML(v)}</option>`).join('')}</select></div>`;
}
function renderEvents() {
  const types = [...new Set(entries('event').map(e => e.data.type))].sort();
  return pageIntro('Events & meetings','Events','Find a paper discussion, workshop, or research presentation. No prior journal club experience is needed.') + `<div class="wrap page-content"><div class="events-controls"><div class="period-toggle" role="group" aria-label="Meeting dates"><button type="button" data-period="upcoming" aria-pressed="true" data-state="on">Upcoming meetings</button><button type="button" data-period="past" aria-pressed="false">Past meetings</button></div><p class="fineprint">All times are local to Chicago.</p></div><div class="filter-bar"><div class="search-field">${icon('search')}<input id="event-search" type="search" aria-label="Search events" placeholder="Search by topic, title, or presenter"></div><div class="event-type-filter">${selectControl('event-type','Event type',types,'All event types')}</div><button type="button" class="btn outline small" data-clear="events">Clear filters</button></div><div class="events-view"><p id="event-count" class="count" aria-live="polite"></p><div class="view-toggle" role="group" aria-label="Event display"><button type="button" data-view="list" aria-pressed="true">List</button><button type="button" data-view="calendar" aria-pressed="false">Calendar</button></div></div><div id="event-results"></div><div class="notice">Coming for the first time? ${link('/resources','See how meetings work')}</div></div>`;
}
function matchingEvents() {
  return entries('event').filter(e => (eventState.period === 'past' ? eventHasEnded(e) : !eventHasEnded(e)) && (eventState.type === 'all' || e.data.type === eventState.type) && [e.title,e.data.description,e.data.host].join(' ').toLowerCase().includes(eventState.query.trim().toLowerCase())).sort(compareEvents);
}
function calendarHTML(events) {
  const month = eventState.month || (events[0]?.data.date || chicagoNow()).slice(0,7);
  eventState.month = month;
  const start = new Date(month + '-01T12:00:00Z'), offset = start.getUTCDay();
  const days = new Date(Date.UTC(start.getUTCFullYear(),start.getUTCMonth()+1,0)).getUTCDate();
  const cells = Array.from({length:Math.ceil((offset+days)/7)*7},(_,i) => {
    const day = i-offset+1, date = month + '-' + String(day).padStart(2,'0');
    return `<div>${day > 0 && day <= days ? `<span class="fineprint">${day}</span>${events.filter(e => e.data.date === date).map(e => link('/events/'+e.slug,timeLabel(e.data.start)+' · '+e.title,'',false)).join('')}` : ''}</div>`;
  }).join('');
  const monthly = events.filter(e => e.data.date.startsWith(month));
  return `<div class="calendar-controls"><button type="button" class="btn outline small" data-month="-1" aria-label="Previous month">‹</button><h3>${start.toLocaleDateString('en-US',{month:'long',year:'numeric',timeZone:'UTC'})}</h3><button type="button" class="btn outline small" data-month="1" aria-label="Next month">›</button></div><p class="fineprint">All event times use America/Chicago.</p><div class="calendar-scroll"><div class="calendar-grid">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => `<div class="day-name">${d}</div>`).join('')}${cells}</div></div><div class="calendar-agenda">${monthly.length ? monthly.map(eventRow).join('') : '<p class="notice">No meetings this month. Use the month controls to explore another month.</p>'}</div>`;
}
function updateEvents() {
  const events = matchingEvents(), active = eventState.query || eventState.type !== 'all';
  document.getElementById('event-count').textContent = `${events.length} ${eventState.period} ${events.length === 1 ? 'meeting' : 'meetings'}`;
  document.getElementById('event-results').innerHTML = events.length ? (eventState.view === 'calendar' ? calendarHTML(events) : `<div class="event-list">${(eventState.period === 'past' ? [...events].reverse() : events).map(eventRow).join('')}</div>`) : emptyState(active ? 'No events match your search' : eventState.period === 'past' ? 'No past meetings yet' : 'The next meeting is being planned',active ? 'Try another topic or remove the filters.' : 'Explore a paper discussion while the next meeting takes shape.',link('/papers','Browse papers') + link('/join','Newsletter signup'));
  document.querySelectorAll('[data-period]').forEach(b => { b.setAttribute('aria-pressed',String(b.dataset.period === eventState.period)); b.dataset.state = b.dataset.period === eventState.period ? 'on' : 'off'; });
  document.querySelectorAll('[data-view]').forEach(b => b.setAttribute('aria-pressed',String(b.dataset.view === eventState.view)));
}
function renderEvent(event) {
  const d = event.data, paper = byId(d.paperId), ended = eventHasEnded(event);
  const registration = d.registrationOpen && !ended ? `${registrationLink(event,'Register for this event')}<p class="fineprint attendance-hint">Any email address is welcome. No account needed.</p>` : `<div class="notice">${ended ? 'This meeting has ended.' : 'Registration is not open yet.'} ${link('/events','See upcoming meetings')}</div>`;
  return pageIntro(event.title,'Events','','/events') + `<div class="wrap page-content detail-layout"><section class="panel tinted detail-action" aria-label="Meeting details and registration"><div class="tag-row"><span class="pill">${escapeHTML(d.type)}</span>${d.food ? `<span class="pill gold">${escapeHTML(d.food)}</span>` : ''}${ended ? '<span class="pill neutral">Past meeting</span>' : ''}</div><h2 class="panel-heading">Meeting details</h2>${eventMeta(event)}${registration}<div class="calendar-actions">${externalLink(googleCalendarLink(event),'Google Calendar')}${calendarDownloadLink(event,'Apple / Outlook (.ics)')}</div></section><article class="prose detail-main"><h2>About the meeting</h2>${paragraphs(d.description)}<h3>Hosts & presenters</h3><p>${escapeHTML(d.host || 'Presenter details to be announced.')}</p><h3>Who can attend?</h3><p>Students, faculty, researchers, scientists, and community members are welcome. You do not need to be affiliated with IIT.</p><p>${escapeHTML(d.attendance || 'Contact IBJC with accessibility or attendance questions.')}</p><p>Visiting campus for the first time? ${link('/contact?intent=Accessibility%20or%20campus%20access','Ask about building access or accommodations before you travel.','',false)}</p>${paper ? `<h3>The paper</h3><p>${link('/papers/' + paper.slug,paper.title,'',false)}</p><p>${escapeHTML(paper.data.journal)} · ${escapeHTML(paper.data.year)}</p>` : ''}<h3>How to prepare</h3><p>Read the abstract or bring one question if you have time. Presenters will introduce the background, and you are welcome to listen.</p>${link('/resources','Read the quick orientation')}<h3>Discussion materials</h3>${safeURL(d.slides) ? externalLink(d.slides,'Presentation slides') : '<p class="pending">Presentation slides are not available yet.</p>'}<div class="detail-share">${shareButton('/events/'+event.slug,event.title)}</div></article><aside class="aside-stack detail-secondary"><div class="panel"><h3>Need help attending?</h3><p>Ask about campus access, accommodations, or the meeting format.</p>${link('/contact','Contact IBJC')}</div>${poster(d.image,event.title)}</aside></div>`;
}

function renderPapers() {
  const filter = ([key,label]) => selectControl('filter-'+key,label,[...new Set(entries('paper').flatMap(e => splitList(e.data[key])))].sort(),'Any '+label.toLowerCase());
  return pageIntro('Papers & discussion guides','Papers','Start with a plain-language summary, read the original paper, and bring your questions to a meeting.') + `<div class="wrap page-content"><div class="filter-bar"><div class="search-field">${icon('search')}<input id="paper-search" type="search" aria-label="Search papers" placeholder="Search by title, author, or topic"></div><button type="button" class="btn outline small" data-clear="papers">Clear filters</button></div><div class="paper-primary-filters">${PAPER_FILTERS.slice(0,2).map(filter).join('')}</div><details class="paper-more-filters"><summary class="disclosure-button">More filters</summary><div class="filters-grid">${PAPER_FILTERS.slice(2).map(filter).join('')}</div></details><p class="count" id="paper-count" aria-live="polite"></p><div class="stack" id="paper-results"></div><div class="notice">Original papers open on their publisher or legal repository. ${link('/get-involved?intent=Suggest%20a%20paper','Suggest a paper')}</div></div>`;
}
function updatePapers() {
  const query = document.getElementById('paper-search').value.trim().toLowerCase();
  const found = entries('paper').filter(e => [e.title,e.data.authors,e.data.summary,e.data.topics].join(' ').toLowerCase().includes(query) && PAPER_FILTERS.every(([key]) => { const value = document.getElementById('filter-'+key).value; return value === 'all' || splitList(e.data[key]).includes(value); }));
  document.getElementById('paper-count').textContent = `${found.length} ${found.length === 1 ? 'paper' : 'papers'} found`;
  document.getElementById('paper-results').innerHTML = found.length ? found.map(paperCard).join('') : emptyState('No papers match your search','Try another topic or author, or clear the filters.');
}
function material(url,label) { return safeURL(url) ? `<p>${externalLink(url,label)}</p>` : `<p class="pending">${escapeHTML(label)}: not yet available.</p>`; }
function renderPaper(paper) {
  const d = paper.data, event = entries('event').find(e => e.data.paperId === paper.id);
  const sections = [['In plain language','summary'],['Central research question','question'],['Hypothesis or main idea','hypothesis'],['Methods overview','methods'],['Main findings','findings'],['Important limitations','limitations']];
  return pageIntro(paper.title,'Papers',`${d.journal} · ${d.year} · ${d.level} discussion guide`,'/papers') + `<div class="wrap page-content detail-layout"><section class="panel tinted detail-action" aria-label="Read the original paper"><h2 class="panel-heading">Read the original paper</h2>${externalLink(d.repositoryUrl,'Read free full text','btn')}${externalLink(d.officialUrl,'Publisher’s paper','text-link source-link')}${externalLink(d.pdfUrl,'Open-access PDF','text-link source-link')}<p class="fineprint">Full text opens on the publisher or legal repository. Available download formats are listed there.</p><nav class="page-jumps" aria-label="In this discussion guide">${[['Summary','summary'],['Methods','methods'],['Findings','findings'],['Discussion questions','questions']].map(([label,id]) => `<a href="#paper-${id}">${label}</a>`).join('')}</nav></section><article class="prose detail-main">${tags(d.topics)}<p>${escapeHTML(d.authors)}</p><p class="citation-doi">DOI: ${escapeHTML(d.doi || 'To be added')}</p>${sections.map(([heading,key]) => `<section id="paper-${key}"><h2>${heading}</h2>${paragraphs(d[key] || 'Discussion content to be added.')}</section>`).join('')}<section id="paper-questions"><h2>Questions for the room</h2><ol>${String(d.questions || '').split('\n').filter(Boolean).map(q => `<li>${escapeHTML(q)}</li>`).join('')}</ol></section><p class="fineprint">IBJC’s guide is a starting point for discussion. Consult the original paper for the complete evidence.</p><div class="detail-share">${shareButton('/papers/'+paper.slug,paper.title)}</div></article><aside class="aside-stack detail-secondary"><div class="panel"><h3>Our discussion</h3><p><strong>${prettyDate(d.discussionDate)}</strong><br>${escapeHTML(d.meetingType)}</p><p class="spaced">Presenters:<br>${escapeHTML(d.presenters || 'To be confirmed')}</p>${event ? link('/events/'+event.slug,'View the meeting','btn outline') : ''}<h4 class="spaced">Related disciplines</h4>${tags(d.disciplines)}</div><div class="panel"><h3>Discussion materials</h3>${material(d.slides,'Presentation slides')}${material(d.notes,'Meeting notes')}${material(d.materials,'Orientation materials')}${link('/resources','Browse reading guides')}</div></aside></div>`;
}
function poster(url,title) {
  return safeURL(url) ? `<a class="poster-link" href="${escapeHTML(safeURL(url))}" target="_blank" rel="noopener noreferrer"><img src="${escapeHTML(safeURL(url))}" alt="Poster for ${escapeHTML(title)}" loading="lazy"></a>` : '';
}
function renderNews() {
  const news = entries('news').sort((a,b) => b.data.date.localeCompare(a.data.date));
  return pageIntro('From the IBJC community.','News','Meeting announcements, paper selections, workshops, and the people moving our conversations forward.') + `<div class="wrap page-content"><div class="news-grid">${news.map(n => `<article class="news-card"><div class="news-body">${tags(n.data.tags)}<h3>${link('/news/'+n.slug,n.title,'',false)}</h3><span class="fineprint">${prettyDate(n.data.date)} · ${escapeHTML(n.data.author || 'IBJC')}</span><p class="spaced">${escapeHTML(n.data.summary)}</p>${link('/news/'+n.slug,'Read announcement')}</div></article>`).join('')}</div>${!news.length ? emptyState('Announcements are on the way','New events, collaborations, student achievements, and research opportunities will appear here.') : ''}<div class="notice">Have a Chicago-area biology opportunity, collaboration, or student achievement to share? ${link('/contact','Let us know')}</div></div>`;
}
function renderNewsDetail(entry) {
  const d = entry.data, event = byId(d.eventId), paper = byId(d.paperId);
  return pageIntro(entry.title,'News',d.summary,'/news') + `<div class="wrap page-content two-column"><article class="prose"><p class="fineprint">${prettyDate(d.date)} · ${escapeHTML(d.author || 'IBJC')}</p>${tags(d.tags)}${paragraphs(d.body)}${shareButton('/news/'+entry.slug,entry.title)}</article><aside class="aside-stack">${event ? `<div class="panel tinted"><h3>${escapeHTML(event.title)}</h3>${eventMeta(event)}${link('/events/'+event.slug,'View event','btn')}</div>` : ''}${paper ? `<div class="panel"><h3>Related reading</h3><p>${escapeHTML(paper.title)}</p>${link('/papers/'+paper.slug,'Open discussion guide','btn outline')}</div>` : ''}${poster(d.image,entry.title)}</aside></div>`;
}
function renderTeam() {
  return pageIntro('The people behind the conversation.','Team','A student-led club, supported by people who care about making research more approachable.') + `<div class="wrap page-content">${TEAM_GROUPS.map(group => {
    const people = entries('team').filter(e => e.data.group === group).sort((a,b) => a.id === 'ezequiel-lisondo' ? -1 : b.id === 'ezequiel-lisondo' ? 1 : a.title.localeCompare(b.title));
    return `<section class="team-section"><h2>${group}</h2>${people.length ? `<div class="cards-3">${people.map(person => {
      const d = person.data;
      return `<article class="profile-card">${safeURL(d.photo) ? `<img class="avatar-initials" src="${escapeHTML(safeURL(d.photo))}" alt="${escapeHTML(person.title)}" loading="lazy">` : `<div class="avatar-initials" aria-hidden="true">${escapeHTML(person.title.split(' ').slice(0,2).map(w => w[0]).join(''))}</div>`}<h3>${escapeHTML(person.title)}</h3><p class="role">${escapeHTML(d.role)}</p>${d.placeholder ? '<span class="pill neutral profile-pending">Profile details pending</span>' : ''}<p class="bio preline">${escapeHTML(d.bio)}</p>${d.affiliation ? `<p class="bio spaced">${escapeHTML(d.affiliation)}</p>` : ''}${d.interests ? `<p class="bio spaced">Research interests: ${escapeHTML(d.interests)}</p>` : ''}<div class="profile-links">${d.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email) ? `<a class="text-link" href="mailto:${escapeHTML(d.email)}" aria-label="Email ${escapeHTML(person.title)}">Email</a>` : ''}${externalLink(d.link,'Professional profile')}</div></article>`;
    }).join('')}</div>` : `<div class="panel tinted"><p>${group === 'Student presenters' ? 'Student presenters are listed with each paper discussion.' : group === 'Collaborators' ? 'Future collaborations will be announced here.' : 'Confirmed speakers and research affiliations will be added here.'} ${link('/get-involved','Get involved')}</p></div>`}</section>`;
  }).join('')}</div>`;
}
function resourceDownload(resource) {
  return safeURL(resource.data.fileUrl) ? externalLink(resource.data.fileUrl,'Download') : `<button type="button" class="text-link download-link" data-resource="${escapeHTML(resource.id)}">${icon('download')} Download</button>`;
}
function renderResources() {
  const resources = entries('resource');
  const slides = CONTENT.filter(e => e.status === 'published' && ['paper','event'].includes(e.kind) && safeURL(e.data.slides));
  return pageIntro('Your first paper starts here.','Orientation & Resources','You do not need a research background to join the conversation. These guides give you a practical place to begin.') + `<div class="wrap page-content"><div class="panel tinted orientation-intro"><div class="eyebrow">If you only have ten minutes</div><h2>Read the abstract. Look at a figure. Bring a question.</h2><p class="spaced">Being curious is enough to get started. You can also come to listen.</p></div><div class="accordion-section">${ORIENTATION.map(([question,answer]) => `<details class="faq"><summary>${escapeHTML(question)}</summary><p>${escapeHTML(answer)}</p></details>`).join('')}</div><div class="section-heading"><div><div class="eyebrow">Take the next step</div><h2>Guides you can keep.</h2><p>Read online or download a lightweight, printable text version.</p></div></div><div class="resource-grid">${resources.map(r => `<article class="resource-card"><div class="icon-box">${icon('file')}</div><div><h3>${escapeHTML(r.title)}</h3><p>${escapeHTML(r.data.description)}</p><div class="actions">${link('/resources/'+r.slug,'Read guide')}${resourceDownload(r)}</div></div></article>`).join('')}</div>${!resources.length ? emptyState('Downloadable guides are being prepared','The orientation questions above are ready to use. Approved reading guides will be published here.') : ''}<h2 class="section-subheading">Previous presentation slides</h2>${slides.length ? slides.map(s => `<div class="panel"><h3>${escapeHTML(s.title)}</h3>${material(s.data.slides,'Download slides')}</div>`).join('') : emptyState('Presentation materials are being prepared','Slides will appear here once presenters have approved them for public sharing.')}</div>`;
}
function renderResource(resource) {
  return pageIntro(resource.title,'Orientation & Resources',resource.data.description,'/resources') + `<div class="wrap page-content"><div class="actions resource-actions">${resourceDownload(resource)}<button type="button" class="btn outline" data-print>Print this page</button></div><article class="prose preline">${escapeHTML(resource.data.body || 'Read the attached resource for the complete guide.')}</article></div>`;
}
function renderInvolved(intent = '') {
  const groups = [['Students','Attend a meeting, suggest a paper, present with peers, or help with communications, design, and outreach. No research experience is required.','Attend an event','/events'],['Faculty & researchers','Lead a workshop, share your research, or help students learn how to evaluate a scientific argument.','Propose a presentation','/contact?intent=Give%20a%20research%20presentation'],['Student organizations','Plan a shared discussion, introduce a new perspective, or collaborate on an event for your communities.','Start a collaboration','/contact?intent=Collaborate'],['Chicago scientific communities','Join the discussion, share opportunities, or sponsor and support an accessible learning event.','Connect with IBJC','/contact']];
  return pageIntro('Bring your questions. Bring your perspective.','Get Involved','Attend, present, suggest a paper, or help shape the next conversation. There are many ways to be part of IBJC.') + `<div class="wrap page-content"><div class="split-involvement">${groups.map(([title,body,label,path]) => `<div class="panel"><div class="icon-box">${icon('people')}</div><h3>${title}</h3><p>${body}</p>${link(path,label)}</div>`).join('')}</div><div class="two-column" id="collaboration"><section><div class="eyebrow">Let’s connect</div><h2 class="spaced">What would you like to bring?</h2>${securePanel('inquiry','',intent)}</section><aside class="aside-stack"><div class="panel tinted"><h3>Have a paper in mind?</h3><p>Include the title or DOI, a legal source link, and a few lines about why it would make a good discussion.</p></div><div class="panel"><h3>Just want to stay in the loop?</h3><p>Join the public newsletter with any email address.</p>${link('/join','Join the newsletter','btn outline')}</div></aside></div></div>`;
}
function renderContact(intent = '') {
  return pageIntro('Start a conversation with us.','Contact','Questions about a meeting, an idea for IBJC, or help with attending? Send a note to the officers.') + `<div class="wrap page-content two-column">${securePanel('inquiry','',intent)}<aside class="aside-stack"><div class="panel tinted"><h3>Based in Chicago</h3><p>Interdisciplinary Biology Journal Club<br>Illinois Institute of Technology<br>Chicago, Illinois</p><p class="spaced">Check each event page for its room and attendance details.</p></div><div class="panel"><h3>Access & accommodations</h3><p>Please contact us before attending if you need an accommodation or information about campus access.</p></div><div class="panel"><h3>Present or collaborate</h3><p>We welcome workshop ideas, research talks, paper suggestions, and collaborations.</p>${link('/get-involved','Explore ways to participate')}</div></aside></div>`;
}
function renderRegister(eventId = '') {
  const event = byId(eventId), open = upcomingEvents().filter(e => e.data.registrationOpen);
  let content;
  if (eventId && (!event || !open.some(e => e.id === eventId))) content = emptyState('Registration is not open for that meeting',event ? event.title + ' is not currently accepting registrations.' : 'That event could not be found.',link('/events','Find an upcoming meeting','btn'));
  else if (open.length) content = `${event ? `<div class="registration-summary"><h2>${escapeHTML(event.title)}</h2>${eventMeta(event)}</div>` : ''}${securePanel('register',eventId)}`;
  else content = emptyState('No meetings are currently accepting registrations','Check back for the next meeting, or join the newsletter for future announcements.',link('/events','Explore the meetings') + link('/join','Newsletter signup'));
  return pageIntro('Register for an event','Event registration','Everyone is welcome: students, faculty, researchers, scientists, and curious community members.') + `<div class="wrap page-content two-column"><section>${content}<p class="fineprint spaced">This copy reflects published content on ${CONFIG.snapshotDate}. ${externalLink(CONFIG.liveSite+'/register','Check live registration availability')}</p></section><aside class="aside-stack"><div class="panel tinted"><h3>Your first journal club?</h3><p>You do not need to understand the whole paper. Presenters introduce the background and guide the discussion. Listening is welcome.</p>${link('/resources','Read the quick orientation')}</div><div class="panel"><h3>Visiting from outside IIT?</h3><p>No IIT email, student account, or research experience is required. Check the meeting’s location and attendance notes before traveling.</p></div></aside></div>`;
}
function renderJoin() {
  return pageIntro('IBJC newsletter','Newsletter','Sign up for future event announcements, paper selections, and club updates. Any email address is welcome.') + `<div class="wrap page-content two-column">${securePanel('newsletter')}<aside class="aside-stack"><div class="panel tinted"><h3>Open to the wider community</h3><p>Students, faculty, researchers, scientists, and community members can sign up. No account or IIT affiliation is needed.</p></div><div class="panel"><h3>Want to attend a meeting?</h3><p>Newsletter signup does not register you for an event.</p>${link('/events','Find an upcoming meeting','btn outline')}</div></aside></div>`;
}
function renderPrivacy() {
  return pageIntro('Privacy notice','Privacy','How this exported website handles information.') + `<div class="wrap page-content prose"><p class="fineprint">Exported ${CONFIG.snapshotDate}</p><h2>This public copy</h2><p>This static website contains published club content. It has no registration database, newsletter database, analytics, tracking cookies, or officer records. It does not save personal information in your browser.</p><h2>Registration, newsletter, and contact</h2><p>These actions open the live IBJC website in a new tab. Any information you submit there is handled by that site’s server and restricted to authorized administrators. Read its privacy notice before submitting a form.</p><p>${externalLink(CONFIG.liveSite+'/privacy','Read the live IBJC privacy notice')}</p><h2>External services and links</h2><p>Publisher links, Google Calendar, professional profiles, and the live IBJC website are external services with their own privacy practices. Externally hosted profile images, if any, are requested from their image host. Your hosting provider may process normal web request logs.</p><h2>Newsletter preferences</h2><p>Use the private unsubscribe link provided by the live site when you signed up. If you cannot find it, contact IBJC to request help. Unsubscribing does not cancel an event registration.</p><h2>Questions or corrections</h2><p>${link('/contact?intent=Privacy%20or%20subscription%20request','Contact the officers about privacy, corrections, or removal requests.','',false)}</p></div>`;
}
function renderTerms() {
  return pageIntro('Participation notice','Participation notice','A shared standard for thoughtful scientific conversation.') + `<div class="wrap page-content prose"><h2>Learn, ask, and disagree respectfully</h2><p>IBJC is a student-led journal club. People at different stages of learning are welcome. Critique evidence and ideas, respect other participants, and make space for basic questions.</p><h2>Event information</h2><p>Dates, rooms, presenters, food, and attendance arrangements can change. This export is a snapshot, not a live content feed. Check the current event page before attending.</p><h2>Educational discussion</h2><p>Paper summaries and conversations are for scientific learning. A discussion guide is not a substitute for the original publication, professional advice, or a complete review of a research topic.</p><h2>Materials and permissions</h2><p>Research papers are linked to official sources or legal repositories. Copyright remains with the relevant authors or publishers. Share slides, photos, or other materials only when you have permission. Obtain consent before recording or photographing participants.</p><h2>Independent student organization</h2><p>IBJC was founded at Illinois Institute of Technology in 2026. It is not presented here as a university department. Individual participants’ views do not represent IBJC or the university.</p><h2>Questions or concerns</h2><p>${link('/contact','Contact IBJC about participation, accessibility, or published material.','',false)}</p></div>`;
}
function renderNotFound() {
  return pageIntro('We couldn’t find that page.','Page not found','The page may have moved, or the address may be incomplete.') + `<div class="wrap page-content"><div class="actions">${link('/','Return home','btn')}${link('/events','Browse events','btn outline')}</div></div>`;
}

// RFC 5545 calendar export. Local event times explicitly use America/Chicago.
function calendarFile(event) {
  const esc = v => String(v || '').replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
  const local = (date,time) => date.replaceAll('-','') + 'T' + time.replaceAll(':','') + '00';
  const d = event.data;
  const lines = ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//IBJC//Event Calendar//EN','CALSCALE:GREGORIAN','METHOD:PUBLISH','X-WR-TIMEZONE:America/Chicago','BEGIN:VTIMEZONE','TZID:America/Chicago','X-LIC-LOCATION:America/Chicago','BEGIN:DAYLIGHT','TZOFFSETFROM:-0600','TZOFFSETTO:-0500','TZNAME:CDT','DTSTART:20070311T020000','RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU','END:DAYLIGHT','BEGIN:STANDARD','TZOFFSETFROM:-0500','TZOFFSETTO:-0600','TZNAME:CST','DTSTART:20071104T020000','RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU','END:STANDARD','END:VTIMEZONE','BEGIN:VEVENT',`UID:${event.id}@ibjc`,`DTSTAMP:${new Date(event.updatedAt).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'')}`,`SEQUENCE:${event.revision || 1}`,`DTSTART;TZID=America/Chicago:${local(d.date,d.start)}`,`DTEND;TZID=America/Chicago:${local(d.date,d.end)}`,`SUMMARY:${esc(event.title)}`,`LOCATION:${esc(d.location)}`,`DESCRIPTION:${esc(d.description+'\n\n'+CONFIG.liveSite+'/events/'+event.slug)}`,`URL:${CONFIG.liveSite}/events/${event.slug}`,'STATUS:CONFIRMED','END:VEVENT','END:VCALENDAR'];
  const fold = line => { let out = '', part = ''; const encoder = new TextEncoder(); for (const c of line) { if (encoder.encode(part+c).length > 73) { out += part+'\r\n '; part = ''; } part += c; } return out+part; };
  return lines.map(fold).join('\r\n')+'\r\n';
}
function googleCalendarLink(event) {
  const d = event.data, local = (date,time) => date.replaceAll('-','')+'T'+time.replaceAll(':','')+'00';
  return 'https://calendar.google.com/calendar/render?' + new URLSearchParams({action:'TEMPLATE',text:event.title,dates:local(d.date,d.start)+'/'+local(d.date,d.end),ctz:CONFIG.timeZone,details:d.description+'\n\n'+CONFIG.liveSite+'/events/'+event.slug,location:d.location});
}
function download(filename,text,type) {
  const url = URL.createObjectURL(new Blob([text],{type}));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename;
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url),1000);
}

// Hash navigation works on ordinary static hosting and when opening index.html.
function routeContent(path,params = new URLSearchParams()) {
  const parts = path.split('/').filter(Boolean), section = parts[0], slug = parts[1];
  const kinds = {events:'event',papers:'paper',news:'news',resources:'resource'};
  if (slug || parts.length > 1) {
    if (parts.length !== 2 || !kinds[section]) return renderNotFound();
    const entry = entries(kinds[section]).find(e => e.slug === slug);
    if (!entry) return renderNotFound();
    return ({events:renderEvent,papers:renderPaper,news:renderNewsDetail,resources:renderResource})[section](entry);
  }
  const routes = {'/':renderHome,'/about':renderAbout,'/events':renderEvents,'/papers':renderPapers,'/news':renderNews,'/team':renderTeam,'/resources':renderResources,'/get-involved':() => renderInvolved(params.get('intent') || ''),'/contact':() => renderContact(params.get('intent') || ''),'/register':() => renderRegister(params.get('event') || ''),'/join':renderJoin,'/privacy':renderPrivacy,'/terms':renderTerms,'/unsubscribe':() => pageIntro('Newsletter preferences','Newsletter') + `<div class="wrap page-content prose"><p>Use the private unsubscribe link from your original signup on the live website. This public export does not contain subscription records.</p>${link('/contact?intent=Privacy%20or%20subscription%20request','Contact IBJC for help','btn')}</div>`};
  return (routes[path] || renderNotFound)();
}
function closeMenu() {
  const button = document.querySelector('.mobile-trigger'), nav = document.getElementById('mobile-navigation');
  nav.hidden = true; button.setAttribute('aria-expanded','false'); button.setAttribute('aria-label','Open navigation');
}
function renderRoute(initial = false) {
  const raw = location.hash.startsWith('#/') ? location.hash.slice(1) : '/';
  const url = new URL(raw,'https://ibjc.example');
  const path = url.pathname.replace(/\/$/,'') || '/';
  eventState = {period:'upcoming',query:'',type:'all',view:'list',month:''};
  const main = document.getElementById('main'); main.innerHTML = routeContent(path,url.searchParams);
  document.querySelectorAll('.nav-link').forEach(a => {
    const target = a.getAttribute('href').slice(1), active = target === path || (target !== '/' && path.startsWith(target+'/'));
    a.classList.toggle('active',active); if (active) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
  });
  if (path === '/events') updateEvents();
  if (path === '/papers') updatePapers();
  document.title = path === '/' ? CONFIG.siteTitle : (main.querySelector('h1')?.textContent || 'Page not found')+' | IBJC';
  document.querySelector('meta[name="description"]').content = main.querySelector('.lead')?.textContent || CONFIG.description;
  closeMenu();
  if (!initial) { main.focus({preventScroll:true}); window.scrollTo({top:0,behavior:'instant'}); }
}
function bindInteractions() {
  document.addEventListener('click',async event => {
    const button = event.target.closest('button'), anchor = event.target.closest('a');
    if (button?.classList.contains('mobile-trigger')) {
      const nav = document.getElementById('mobile-navigation'); nav.hidden = !nav.hidden;
      button.setAttribute('aria-expanded',String(!nav.hidden)); button.setAttribute('aria-label',nav.hidden ? 'Open navigation' : 'Close navigation');
    }
    if (anchor && anchor.getAttribute('href')?.startsWith('#') && !anchor.getAttribute('href').startsWith('#/')) {
      const target = document.getElementById(anchor.getAttribute('href').slice(1));
      if (target) { event.preventDefault(); target.setAttribute('tabindex','-1'); target.focus({preventScroll:true}); target.scrollIntoView({block:'start'}); }
    }
    if (!button) return;
    if (button.dataset.period) { eventState.period = button.dataset.period; eventState.month = ''; updateEvents(); }
    if (button.dataset.view) { eventState.view = button.dataset.view; updateEvents(); }
    if (button.dataset.month) {
      const date = new Date(eventState.month+'-01T12:00:00Z'); date.setUTCMonth(date.getUTCMonth()+Number(button.dataset.month)); eventState.month = date.toISOString().slice(0,7);
      const direction = button.dataset.month; updateEvents(); document.querySelector(`[data-month="${direction}"]`)?.focus();
    }
    if (button.dataset.clear === 'events') { document.getElementById('event-search').value = ''; document.getElementById('event-type').value = 'all'; eventState.query = ''; eventState.type = 'all'; updateEvents(); }
    if (button.dataset.clear === 'papers') { document.getElementById('paper-search').value = ''; PAPER_FILTERS.forEach(([key]) => { document.getElementById('filter-'+key).value = 'all'; }); updatePapers(); }
    if (button.dataset.calendar) { const entry = byId(button.dataset.calendar); if (entry?.kind === 'event') download(entry.slug+'.ics',calendarFile(entry),'text/calendar;charset=utf-8'); }
    if (button.dataset.resource) { const entry = byId(button.dataset.resource); if (entry?.kind === 'resource') download(entry.slug+'.txt',entry.title+'\n\n'+(entry.data.body || ''),'text/plain;charset=utf-8'); }
    if (button.hasAttribute('data-print')) window.print();
    if (button.dataset.share) {
      const url = CONFIG.liveSite+button.dataset.share, feedback = button.nextElementSibling;
      try { if (navigator.share) await navigator.share({title:button.dataset.title,url}); else { await navigator.clipboard.writeText(url); feedback.textContent = 'Link copied.'; } }
      catch (error) { if (error.name !== 'AbortError') { feedback.textContent = 'Copy this live page address: '+url; } }
    }
  });
  document.addEventListener('input',event => {
    if (event.target.id === 'event-search') { eventState.query = event.target.value; updateEvents(); }
    if (event.target.id === 'paper-search') updatePapers();
  });
  document.addEventListener('change',event => {
    if (event.target.id === 'event-type') { eventState.type = event.target.value; eventState.month = ''; updateEvents(); }
    if (event.target.id.startsWith('filter-')) updatePapers();
  });
  document.addEventListener('keydown',event => { if (event.key === 'Escape' && !document.getElementById('mobile-navigation').hidden) { closeMenu(); document.querySelector('.mobile-trigger').focus(); } });
  document.addEventListener('error',event => {
    if (event.target instanceof HTMLImageElement && event.target.classList.contains('avatar-initials')) {
      const initials = document.createElement('div'); initials.className = 'avatar-initials'; initials.setAttribute('aria-label',event.target.alt);
      initials.textContent = event.target.alt.split(' ').slice(0,2).map(x => x[0]).join(''); event.target.replaceWith(initials);
    }
  },true);
  window.addEventListener('hashchange',() => renderRoute());
}

if (typeof document !== 'undefined') {
  bindInteractions();
  renderRoute(true);
}
